# -*- coding: utf-8 -*-
# Magic Keyboard V2 — verb conjugation generator
# Each verb: (inf_f, inf_fa, past_f, past_fa, pr_f, pr_fa, pf_f, pf_fa,
#             subj_f, subj_fa, imp_f, imp_fa)
#   pr    = colloquial present stem     (می‌رم)
#   pf    = formal present stem         (می‌روم)
#   subj  = subjunctive base WITH بـ    (بر + ام = برم)
#   imp   = imperative 2nd singular     (برو)
#
# Generates ~78 forms per verb: past/neg-past, imperfective, present col/formal,
# subjunctive, imperative(+neg), perfect, participle, pluperfect, perfect
# subjunctive, passive-colloquial.

V = [
 # ------- هست‌بود -------
 ("budan","بودن","bood","بود","bash","باش","bash","باش","bash","باش","bash","باش"),
 # ------- حرکت -------
 ("raftan","رفتن","raft","رفت","re","ر","rav","رو","ber","بر","boro","برو"),
 ("amadan","آمدن","amad","آمد","ia","آ","ia","آ","bia","بیا","bia","بیا"),
 ("gashtan","گشتن","gasht","گشت","gard","گرد","gard","گرد","begard","بگرد","begard","بگرد"),
 ("istadan","ایستادن","istad","ایستاد","ist","ایست","ist","ایست","beist","بیست","beist","بیست"),
 ("oftadan","افتادن","oftaad","افتاد","oft","افت","oft","افت","bioft","بیفت","bioft","بیفت"),
 ("bargashtan","برگشتن","bargasht","برگشت","bargard","برگرد","bargard","برگرد","bargard","برگرد","bargard","برگرد"),
 ("rasidan","رسیدن","reesid","رسید","res","رس","res","رس","beres","برس","beres","برس"),
 ("khastan","خاستن","khaast","خاست","khiz","خیز","khiz","خیز","barkhiz","برخیز","barkhiz","برخیز"),
 ("barkhestan","برخاستن","barkhast","برخاست","barkhiz","برخیز","barkhiz","برخیز","barkhiz","برخیز","barkhiz","برخیز"),
 ("paridan","پریدن","parid","پرید","par","پر","par","پر","bepar","بپر","bepar","بپر"),
 ("davidan","دویدن","david","دوید","dav","دو","dav","دو","bedav","بدو","bedav","بدو"),
 ("raftan2","رقصیدن","raghsid","رقصید","raghs","رقص","raghs","رقص","beraghs","برقص","beraghs","برقص"),
 ("charkhidan","چرخیدن","charkhid","چرخید","charkh","چرخ","charkh","چرخ","becharkh","بچرخ","becharkh","بچرخ"),
 ("parvaz", "پرواز کردن","parvaz kard","پرواز کرد","parvaz kon","پرواز کن","parvaz kon","پرواز کن","parvaz bekon","پرواز بکن","parvaz bekon","پرواز بکن"),
 # ------- ادراک -------
 ("didan","دیدن","deed","دید","bin","بین","bin","بین","bebin","ببین","bebin","ببین"),
 ("shenidan","شنیدن","sheenid","شنید","shenav","شنو","shenav","شنو","beshenav","بشنو","beshenav","بشنو"),
 ("danestan","دانستن","danest","دانست","dun","دون","dan","دان","bedun","بدون","bedun","بدون"),
 ("fahmidan","فهمیدن","fahmid","فهمید","fahm","فهم","fahm","فهم","befahm","بفهم","befahm","بفهم"),
 ("yad gereftan","یادگرفتن","yad gereft","یادگرفت","yad gir","یادگیر","yad gir","یادگیر","yad begir","یادبگیر","yad begir","یادبگیر"),
 ("shenakhtan","شناختن","shenakht","شناخت","shenas","شناس","shenas","شناس","beshenas","بشناس","beshenas","بشناس"),
 ("negaristan","نگریستن","negarist","نگریست","negar","نگر","negar","نگر","benegar","بنگر","benegar","بنگر"),
 ("andishidan","اندیشیدن","andishid","اندیشید","andish","اندیش","andish","اندیش","beandish","بیندیش","beandish","بیندیش"),
 # ------- گفتاری -------
 ("goftan","گفتن","gooft","گفت","go","گو","gav","گو","bego","بگو","bogo","بگو"),
 ("porsidan","پرسیدن","poorsid","پرسید","pors","پرس","pors","پرس","bepors","بپرس","bepors","بپرس"),
 ("javab dadan","جواب‌دادن","javab dad","جواب‌داد","javab de","جواب‌ده","javab deh","جواب‌ده","javab bedeh","جواب‌بده","javab bedeh","جواب‌بده"),
 ("sohbat kardan","صحبت‌کردن","sohbat kard","صحبت‌کرد","sohbat kon","صحبت‌کن","sohbat kon","صحبت‌کن","sohbat bekon","صحبت‌بکن","sohbat bekon","صحبت‌بکن"),
 ("khandan","خواندن","khaand","خواند","khan","خوان","khan","خوان","bekhan","بخوان","bekhan","بخوان"),
 ("neveshtan","نوشتن","nevesht","نوشت","nevis","نویس","nevis","نویس","benevis","بنویس","benevis","بنویس"),
 ("faryad zadan","فریادزدن","faryad zad","فریادزد","faryad zan","فریادزن","faryad zan","فریادزن","faryad bezan","فریادبزن","faryad bezan","فریادبزن"),
 # ------- عمل -------
 ("kardan","کردن","kard","کرد","kon","کن","kon","کن","bekon","بکن","kon","کن"),
 ("shodan","شدن","shod","شد","sho","شو","shav","شو","beshav","بشو","sho","شو"),
 ("dashtan","داشتن","dasht","داشت","dar","دار","dar","دار","bedar","بدار","bedar","بدار"),
 ("dadаn","دادن","daad","داد","d","د","deh","ده","bedeh","بده","bedeh","بده"),
 ("gereftan","گرفتن","gereft","گرفت","gir","گیر","gir","گیر","begir","بگیر","begir","بگیر"),
 ("bordan","بردن","boord","برد","bar","بُر","bar","بُر","bebar","ببر","bebar","ببر"),
 ("avardan","آوردن","avard","آورد","avar","آور","avar","آور","biar","بیار","biar","بیار"),
 ("zadan","زدن","zad","زد","zan","زن","zan","زن","bezan","بزن","bezan","بزن"),
 ("gozashtan","گذاشتن","gozasht","گذاشت","gozar","گذار","gozar","گذار","begozar","بگذار","begozar","بگذار"),
 ("sakhtan","ساختن","sakht","ساخت","saz","ساز","saz","ساز","besaz","بساز","besaz","بساز"),
 ("bastan","بستن","bast","بست","band","بند","band","بند","beband","ببند","beband","ببند"),
 ("keshidan","کشیدن","keshid","کشید","kesh","کش","kesh","کش","bekesh","بکش","bekesh","بکش"),
 ("andakhtan","انداختن","andakht","انداخت","andaz","انداز","andaz","انداز","beandaz","بینداز","beandaz","بینداز"),
 ("ferestadan","فرستادن","ferestaad","فرستاد","ferest","فرست","ferest","فرست","beferest","بفرست","beferest","بفرست"),
 ("sepordan","سپردن","sepord","سپرد","sepor","سپر","sepor","سپر","besepor","بسپر","besepor","بسپر"),
 ("resandan","رساندن","resand","رساند","resan","رسان","resan","رسان","beresan","برسان","beresan","برسان"),
 ("neshandan","نشاندن","neshand","نشاند","neshan","نشان","neshan","نشان","beneshan","بنشان","beneshan","بنشان"),
 ("pardakhtan","پرداختن","pardakht","پرداخت","pardaz","پرداز","pardaz","پرداز","bepardaz","بپرداز","bepardaz","بپرداز"),
 ("feshordan","فشردن","feshord","فشرد","feshor","فشر","feshor","فشر","befeshor","بفشر","befeshor","بفشر"),
 ("kobidan","کوبیدن","koobid","کوبید","koob","کوب","koob","کوب","bekoob","بکوب","bekoob","بکوب"),
 ("peichidan","پیچیدن","peichid","پیچید","peich","پیچ","peich","پیچ","bepeich","بپیچ","bepeich","بپیچ"),
 ("boridan","بریدن","borid","برید","bor","بُر","bor","بُر","bebor","ببُر","bebor","ببُر"),
 # ------- مصرف -------
 ("khordan","خوردن","khood","خورد","khor","خور","khor","خور","bokhor","بخور","bokhor","بخور"),
 ("nooshidan","نوشیدن","nooshid","نوشید","noosh","نوش","noosh","نوش","benoosh","بنوش","benoosh","بنوش"),
 ("pokhtan","پختن","pokht","پخت","paz","پز","paz","پز","bepaz","بپز","bepaz","بپز"),
 ("shostan","شستن","shoost","شست","shoor","شور","shoor","شور","beshoor","بشور","beshoor","بشور"),
 ("pooshidan","پوشیدن","pooshid","پوشید","poosh","پوش","poosh","پوش","bepoosh","بپوش","bepoosh","بپوش"),
 ("kharidan","خریدن","kharid","خرید","khar","خر","khar","خر","bekhar","بخر","bekhar","بخر"),
 ("forookhtan","فروختن","forookht","فروخت","foroosh","فروش","foroosh","فروش","beforoosh","بفروش","beforoosh","بفروش"),
 ("kashtan","کاشتن","kaasht","کاشت","kar","کار","kar","کار","bekar","بکار","bekar","بکار"),
 ("chidan","چیدن","cheed","چید","chin","چین","chin","چین","bechin","بچین","bechin","بچین"),
 ("dookhtan","دوختن","dookht","دوخت","dooz","دوز","dooz","دوز","bedooz","بدوز","bedooz","بدوز"),
 ("baftan","بافتن","baft","بافت","baaf","باف","baaf","باف","bebaaf","بباف","bebaaf","بباف"),
 ("malidan","مالیدن","malid","مالید","mal","مال","mal","مال","bemal","بمال","bemal","بمال"),
 ("tarashidan","تراشیدن","taraashid","تراشید","taraash","تراش","taraash","تراش","betaraash","بتراش","betaraash","بتراش"),
 ("poosidan","پوسیدن","poosid","پوسید","poos","پوس","poos","پوس","bepoos","بپوس","bepoos","بپوس"),
 # ------- حالت -------
 ("khabidan","خوابیدن","khabid","خوابید","khab","خواب","khab","خواب","bekhab","بخواب","bekhab","بخواب"),
 ("mordan","مردن","mord","مرد","mir","میر","mir","میر","bemir","بمیر","bemir","بمیر"),
 ("zistan","زیستن","zist","زیست","zi","زی","zi","زی","bezi","بزی","bezi","بزی"),
 ("sookhtan","سوختن","sookht","سوخت","sooz","سوز","sooz","سوز","besooz","بسوز","besooz","بسوز"),
 ("larzidan","لرزیدن","larzid","لرزید","larz","لرز","larz","لرز","belarz","بلرز","belarz","بلرز"),
 ("jooshidan","جوشیدن","jooshid","جوشید","joosh","جوش","joosh","جوش","bejoosh","بجوش","bejoosh","بجوش"),
 ("derakhshidan","درخشیدن","derakhshid","درخشید","derakhsh","درخش","derakhsh","درخش","bederakhsh","بدرخش","bederakhsh","بدرخش"),
 ("baridan","باریدن","barid","بارید","bar","بار","bar","بار","bebar","ببار","bebar","ببار"),
 ("chasbidan","چسبیدن","chasbid","چسبید","chasb","چسب","chasb","چسب","bechasb","بچسب","bechasb","بچسب"),
 ("tarsidan","ترسیدن","tarsid","ترسید","tars","ترس","tars","ترس","betars","بترس","betars","بترس"),
 ("khandidan","خندیدن","khandid","خندید","khand","خند","khand","خند","bekhand","بخند","bekhand","بخند"),
 ("geryatan","گریستن","grest","گریست","gery","گری","gery","گری","begery","بگری","begery","بگری"),
 ("boosidan","بوسیدن","boosid","بوسید","boos","بوس","boos","بوس","beboos","ببوس","beboos","ببوس"),
 ("neshastan","نشستن","neshast","نشست","neshin","نشین","neshin","نشین","beneshin","بنشین","beneshin","بنشین"),
 ("shemordan","شمردن","shemord","شمرد","shemor","شمر","shemor","شمر","beshemor","بشمر","beshemor","بشمر"),
 ("sanjidan","سنجیدن","sanjid","سنجید","sanj","سنج","sanj","سنج","besanj","بسنج","besanj","بسنج"),
 ("jostan","جستن","jost","جست","jo","جو","jo","جو","bejo","بجو","bejo","بجو"),
 ("yaftan","یافتن","yaft","یافت","yab","یاب","yab","یاب","beyab","بیاب","beyab","بیاب"),
 ("pasandidan","پسندیدن","pasandid","پسندید","pasand","پسند","pasand","پسند","bepasand","بپسند","bepasand","بپسند"),
 ("bakhshidan","بخشیدن","bakhshid","بخشید","bakhsh","بخش","bakhsh","بخش","bebakhsh","ببخش","bebakhsh","ببخش"),
 ("gozidan","گزیدن","gozid","گزید","gozin","گزین","gozin","گزین","begozin","بگزین","begozin","بگزین"),
 ("navakhtan","نواختن","navakht","نواخت","navaz","نواز","navaz","نواز","benavaz","بنواز","benavaz","بنواز"),
 ("ranandan","راندن","raand","راند","ran","ران","ran","ران","beran","بران","beran","بران"),
 ("nalidan","نالیدن","nalid","نالید","nal","نال","nal","نال","benal","بنال","benal","بنال"),
 ("koshidan","کوشیدن","kooshid","کوشید","koosh","کوش","koosh","کوش","bekoosh","بکوش","bekoosh","بکوش"),
 ("parastidan","پرستیدن","parastid","پرستید","parast","پرست","parast","پرست","beparast","بپرست","beparast","بپرست"),
 ("setoodan","ستودن","setood","ستود","setay","ستای","setay","ستای","besetay","بستای","besetay","بستای"),
 ("pendashtan","پنداشتن","pendasht","پنداشت","pendar","پندار","pendar","پندار","bependar","بپندار","bependar","بپندار"),
 ("khandandan","خنداندن","khandand","خنداند","khandan","خندان","khandan","خندان","bekhandan","بخندان","bekhandan","بخندان"),
 ("pooshandan","پوشاندن","pooshand","پوشاند","pooshan","پوشان","pooshan","پوشان","bepooshan","بپوشان","bepooshan","بپوشان"),
 ("amookhtan","آموختن","amookht","آموخت","amooz","آموز","amooz","آموز","beamooz","بیاموز","beamooz","بیاموز"),
 ("afzoodan","افزودن","afozaad","افزود","afoz","افزو","afoz","افزو","beafoz","بیفزو","beafoz","بیفزو"),
 # ------- خواست/توان -------
 ("khaastan","خواستن","khaast","خواست","kha","خوا","kha","خوا","bekha","بخوا","bekha","بخوا"),
 ("tavanestan","توانستن","tavanest","توانست","tun","تون","tavan","توان","betun","بتون","betun","بتون"),
 ("miaayad?","می‌خواهد","","","","","","","","","",""),
]
V = [x for x in V if x[1] != "می‌خواهد"]  # remove placeholder row

# ---------------- موتور صرف ----------------
PAST_F_END   = ["am", "i", "", "im", "id", "and"]
PAST_FA_END  = ["م", "ی", "", "یم", "ید", "ند"]
COLL_F_END   = ["am", "i", "e", "im", "id", "an"]
COLL_FA_END  = ["م", "ی", "ه", "یم", "ید", "ن"]
FORM_F_END   = ["am", "i", "ad", "im", "id", "and"]
FORM_FA_END  = ["م", "ی", "د", "یم", "ید", "ند"]
PERF_FA      = ["ام", "ای", "است", "ایم", "اید", "اند"]
PERF_F       = ["am", "i", "ast", "im", "id", "and"]
COLL3_FA     = ["م", "ی", "د", "یم", "ید", "ن"]   # stems ending in vowel
COLL3_F      = ["am", "i", "d", "im", "id", "an"]

VOWELS_FA = set("اویآءهی")

def ends_in_vowel_fa(s):
    return bool(s) and s[-1] in VOWELS_FA

IMP_NEG_SPECIAL = {"boro": "ro", "bash": "bash", "beist": "ist"}

def strip_be(f):
    if f in IMP_NEG_SPECIAL:
        return IMP_NEG_SPECIAL[f]
    if f.startswith("be") and len(f) > 2 and not _vowel(f[2]):
        return f[2:]
    if f.startswith("b") and len(f) > 1 and _vowel(f[1]):
        return f[1:]
    return f

def _vowel(c):
    return c in "aeiou"

def strip_b_fa(f):
    return f[1:] if f.startswith("ب") else f

def generate():
    """Returns list of (finglish, persian, rank) — pos=Verb for all."""
    out = []
    for i, verb in enumerate(V):
        (inf_f, inf_fa, past_f, past_fa, pr_f, pr_fa,
         pf_f, pf_fa, subj_f, subj_fa, imp_f, imp_fa) = verb
        base = 1100 + 30 * i
        add = lambda f, fa, r: out.append((f, fa, r))

        # infinitive
        add(inf_f, inf_fa, base - 200)
        # past simple
        for k in range(6):
            add(past_f + PAST_F_END[k], past_fa + PAST_FA_END[k], base)
            add("na" + past_f + PAST_F_END[k], "ن" + past_fa + PAST_FA_END[k], base + 60)
        # imperfective past
        for k in range(6):
            add("mi" + past_f + PAST_F_END[k], "می\u200c" + past_fa + PAST_FA_END[k], base + 20)
            add("nemi" + past_f + PAST_F_END[k], "نمی\u200c" + past_fa + PAST_FA_END[k], base + 80)
        # participle
        add(past_f + "e", past_fa + "ه", base - 60)
        # present colloquial
        vowel_end = ends_in_vowel_fa(pr_fa)
        fe, ff = (COLL3_F, COLL3_FA) if vowel_end else (COLL_F_END, COLL_FA_END)
        for k in range(6):
            add("mi" + pr_f + fe[k], "می\u200c" + pr_fa + ff[k], base - 20)
            add("nemi" + pr_f + fe[k], "نمی\u200c" + pr_fa + ff[k], base + 90)
        # present formal
        for k in range(6):
            add("mi" + pf_f + FORM_F_END[k], "می\u200c" + pf_fa + FORM_FA_END[k], base + 400)
            add("nemi" + pf_f + FORM_F_END[k], "نمی\u200c" + pf_fa + FORM_FA_END[k], base + 440)
        # subjunctive
        sve, svf = (COLL3_F, COLL3_FA) if ends_in_vowel_fa(subj_fa) else (COLL_F_END, COLL_FA_END)
        for k in range(6):
            add(subj_f + sve[k], subj_fa + svf[k], base + 160)
        # imperative
        add(imp_f, imp_fa, base + 200)
        add(imp_f + "id", imp_fa + "ید", base + 220)
        neg_f_core, neg_fa_core = strip_be(imp_f), strip_b_fa(imp_fa)
        add("na" + neg_f_core, "ن" + neg_fa_core, base + 240)
        if _vowel(neg_f_core[0]) and "na" + neg_f_core != "n" + neg_f_core:
            add("n" + neg_f_core, "ن" + neg_fa_core, base + 242)
        add("na" + neg_f_core + "id", "ن" + neg_fa_core + "ید", base + 260)
        # perfect
        for k in range(6):
            add(past_f + "e" + PERF_F[k], past_fa + "ه\u200c" + PERF_FA[k], base + 300)
        # pluperfect
        for k in range(6):
            add(past_f + "ebud" + PAST_F_END[k], past_fa + "ه\u200cبود" + PAST_FA_END[k], base + 500)
        # perfect subjunctive
        for k in range(6):
            add(past_f + "ebash" + COLL_F_END[k], past_fa + "ه\u200cباش" + COLL_FA_END[k], base + 520)
        # passive colloquial
        for k in range(6):
            add(past_f + "esh" + COLL_F_END[k], past_fa + "ه\u200cش" + COLL_FA_END[k], base + 560)

    return out

# ---------------- اصلاحات دستی (فعل‌های ناهم‌قوار) ----------------
FIXUPS = [
    # آمدن — صورت‌های رسمی
    ("miayam","می\u200cآیم"), ("miayi","می\u200cآیی"), ("miayad","می\u200cآید"),
    ("miayim","می\u200cآییم"), ("miayid","می\u200cآیید"), ("miayand","می\u200cآیند"),
    ("miaam","می\u200cآم"), ("miai","می\u200cآی"), ("miaim","می\u200cآیم"),
    # گفتن — رسمی
    ("miguyam","می\u200cگویم"), ("miguyi","می\u200cگویی"), ("miguyad","می\u200cگوید"),
    ("miguyim","می\u200cگوییم"), ("miguyid","می\u200cگویید"), ("miguyand","می\u200cگویند"),
    # خواستن — رسمی
    ("mikaham","می\u200cخواهم"), ("mikahi","می\u200cخواهی"), ("mikahad","می\u200cخواهد"),
    ("mikahim","می\u200cخواهیم"), ("mikahid","می\u200cخواهید"), ("mikahand","می\u200cخواهند"),
    ("mikhamam","می\u200cخواهم"),
    # توانستن — رسمی
    ("mitavanam","می\u200cتوانم"), ("mitavani","می\u200cتوانی"), ("mitavanad","می\u200cتواند"),
    ("mitavanim","می\u200cتوانیم"), ("mitavanid","می\u200cتوانید"), ("mitavanand","می\u200cتوانند"),
    # دانستن — رسمی
    ("midanam","می\u200cدانم"), ("midani","می\u200cدانی"), ("midanad","می\u200cداند"),
    ("midanim","می\u200cدانیم"), ("midanid","می\u200cدانید"), ("midanand","می\u200cدانند"),
    ("bedanam","بدانم"), ("bedani","بدانی"), ("bedanad","بداند"),
    # دادن — رسمی
    ("mideham","می\u200cدهم"), ("midehi","می\u200cدهی"), ("midehad","می\u200cدهد"),
    ("midehim","می\u200cدهیم"), ("midehid","می\u200cدهید"), ("midehand","می\u200cدهند"),
    # انداختن — محاورهٔ رایج
    ("mindazam","می\u200cندازم"), ("mindazi","می\u200cندازی"), ("mindaze","می\u200cندازه"),
    ("mindazim","می\u200cندازیم"), ("mindazid","می\u200cندازید"), ("mindazan","می\u200cندازن"),
    ("bendazam","بندازم"), ("bendazi","بندازی"), ("bendaze","بندازه"),
    ("bendazim","بندازیم"), ("bendazid","بندازید"), ("bendazan","بندازن"),
    ("bendaz","بینداز"),
    # رفتن — صورت‌های پرتکرار
    ("mire","می\u200cره"), ("mira","می\u200cره"), ("mirem","می\u200cرم"),
    ("mirim","می\u200cریم"), ("mirid","می\u200cرید"), ("miran","می\u200cرن"),
    ("miraftam","می\u200cرفتم"), ("mirafti","می\u200cرفتی"), ("miraft","می\u200cرفت"),
    # خواندن محاوره (می‌خونم)
    ("mikhoonam","می\u200cخونم"), ("mikhooni","می\u200cخونی"), ("mikhoone","می\u200cخونه"),
    ("mikhoonim","می\u200cخونیم"), ("mikhoonid","می\u200cخونید"), ("mikhoonan","می\u200cخونن"),
    ("mikhandam","می\u200cخوندم"), ("mikhandi","می\u200cخوندی"), ("mikhand","می\u200cخوند"),
    ("bekhoonam","بخونم"), ("bekhooni","بخونی"), ("bekhoone","بخونه"),
    ("bekhoonim","بخونیم"), ("bekhoonid","بخونید"), ("bekhoonan","بخونن"),
    # خوردن محاوره
    ("mikhoram","می\u200cخورم"), ("mikhori","می\u200cخوری"), ("mikhore","می\u200cخوره"),
    ("mikhorim","می\u200cخوریم"), ("mikhorid","می\u200cخورید"), ("mikhoran","می\u200cخورن"),
    # بودن
    ("mam","مم"), ("may","مایی"), ("mashe","مایش"),
    ("bayam","بایم"), ("nabasham","نباشم"), ("nabashi","نباشی"), ("nabashe","نباشه"),
    # عبارت‌های فعلِ پرتکرار
    ("bidaram","بیدارم"), ("narahatam","ناراحتم"),
]

def generate_all():
    out = generate()
    for f, fa in FIXUPS:
        out.append((f, fa, 200))
    return out

if __name__ == "__main__":
    forms = generate_all()
    print("verb forms generated:", len(forms))
