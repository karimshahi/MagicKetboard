# -*- coding: utf-8 -*-
# Magic Keyboard V2 — logo/icon generator
# Green icon = ON, gray icon = OFF (user requirement)
# Draws a keyboard glyph with a "magic" sparkle on a rounded-square badge.
from PIL import Image, ImageDraw

GREEN_BG  = (34, 197, 94)
GREEN_DK  = (21, 128, 61)
GRAY_BG   = (120, 128, 140)
GRAY_DK   = (90, 97, 108)
WHITE     = (255, 255, 255)
KEY_OFF   = (232, 240, 235)

def rounded(draw, box, radius, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)

def draw_badge(size, on=True):
    S = 4  # supersample
    px = size * S
    img = Image.new("RGBA", (px, px), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    bg  = GREEN_BG if on else GRAY_BG
    dk  = GREEN_DK if on else GRAY_DK

    m = int(px * 0.055)
    rounded(d, (m, m, px - m, px - m), radius=int(px * 0.22), fill=bg + (255,))

    # keyboard body
    kx0, ky0 = int(px*0.16), int(px*0.30)
    kx1, ky1 = int(px*0.84), int(px*0.70)
    rounded(d, (kx0, ky0, kx1, ky1), radius=int(px*0.07), fill=WHITE + (235,))

    # keys: 2 rows of dots + spacebar
    pad = int(px*0.035)
    key = int(px*0.055)
    rows_y = [ky0 + pad, ky0 + pad + key + int(px*0.02)]
    for ry in rows_y:
        x = kx0 + pad
        while x + key <= kx1 - pad:
            rounded(d, (x, ry, x + key, ry + key), radius=int(px*0.012),
                    fill=(70, 80, 74, 255) if on else (60, 66, 72, 255))
            x += key + int(px*0.018)
    # spacebar
    sy = rows_y[1] + key + int(px*0.02)
    rounded(d, (kx0 + pad, sy, kx1 - pad, sy + int(key*0.7)),
            radius=int(px*0.010), fill=(70, 80, 74, 255) if on else (60, 66, 72, 255))

    # magic sparkle (top-right)
    cx, cy = int(px*0.735), int(px*0.215)
    r1, r2 = int(px*0.105), int(px*0.036)
    d.polygon([(cx, cy - r1), (cx + r2, cy - r2), (cx + r1, cy),
               (cx + r2, cy + r2), (cx, cy + r1), (cx - r2, cy + r2),
               (cx - r1, cy), (cx - r2, cy - r2)], fill=WHITE + (255,))

    if size <= 24:
        img = img.resize((size, size), Image.LANCZOS)
    else:
        img = img.resize((size, size), Image.LANCZOS)
    return img

def make_ico(path, on):
    sizes = [16, 20, 24, 32, 40, 48, 64, 128, 256]
    frames = [draw_badge(s, on) for s in sizes]
    frames[-1].save(path, format="ICO",
                    sizes=[(s, s) for s in sizes],
                    append_images=frames[:-1])


import os
os.makedirs("resources/icons", exist_ok=True)
make_ico("resources/icons/mk_on.ico", True)
make_ico("resources/icons/mk_off.ico", False)

# big logo for docs
logo_on  = draw_badge(512, True)
logo_off = draw_badge(512, False)
logo_on.save("resources/icons/logo_on.png")
logo_off.save("resources/icons/logo_off.png")

# combined banner
banner = Image.new("RGBA", (1120, 512), (250, 250, 252, 255))
banner.paste(logo_on, (40, 0), logo_on)
banner.paste(logo_off, (580, 0), logo_off)
banner.save("resources/icons/logo_banner.png")
print("icons generated: mk_on.ico, mk_off.ico, logo_on.png, logo_off.png")
