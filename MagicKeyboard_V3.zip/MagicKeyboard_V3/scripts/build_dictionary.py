# -*- coding: utf-8 -*-
# Magic Keyboard V2 — dictionary builder
# Merges: CORE + EXTRA (curated) + VERBS (generated) + LOANS (parsed from C++)
# Output: resources/dictionary.tsv   (finglish \t persian \t pos \t rank)
#
# IMPORTANT: normalization here MUST match src/core/string_utils.cpp
#            normalize_finglish_key() exactly.

import io
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "mk_data")
ROOT = os.path.dirname(HERE)
for p in (HERE, DATA):
    if p not in sys.path:
        sys.path.insert(0, p)

from data_core import CORE          # noqa: E402
from data_extra import EXTRA        # noqa: E402
from data_v3 import V3              # noqa: E402
from data_verbs import generate_all # noqa: E402

POS_MAP = {
    "": 0, "G": 0, "N": 1, "A": 2, "V": 3, "X": 4, "P": 5,
    "R": 6, "C": 7, "Q": 8, "M": 9, "L": 10, "S": 11, "T": 12,
}

def normalize_key(raw):
    """Mirror of C++ normalize_finglish_key()."""
    k = []
    for ch in raw.lower():
        o = ord(ch)
        if 0x61 <= o <= 0x7A:
            k.append(ch)
        elif ch == "x":
            k.append("kh")
    k = "".join(k).replace("ck", "k")
    k = k.replace("aa", "a").replace("ee", "i").replace("oo", "u")
    # long-o spelled with single o also collapses to u (dost ~ doost)
    k = k.replace("o", "u")
    return k

def parse_loans():
    """Parse the C++ LoanwordEntry table (single source of truth)."""
    src = io.open(os.path.join(ROOT, "src", "core", "loanwords.cpp"),
                  encoding="utf-8").read()
    pat = re.compile(r'\{"([^"]+)",\s*"([^"]+)",\s*"([^"]+)"\}')
    out = []
    for en, fa, fing in pat.findall(src):
        out.append((en, fa, fing))
    return out

def o_variants(raw):
    """Spelling variants: every standalone short 'o' may be typed as 'e'.
    bokhor -> {bokhor, bekhor, bokher, bekher}   (poosh untouched)
    """
    idxs = [i for i, ch in enumerate(raw)
            if ch == "o"
            and (i == 0 or raw[i - 1] != "o")
            and (i + 1 >= len(raw) or raw[i + 1] != "o")]
    outs = {raw}
    for mask in range(1, 1 << len(idxs)):
        s = list(raw)
        for b, i in enumerate(idxs):
            if mask & (1 << b):
                s[i] = "e"
        outs.add("".join(s))
    return outs

def main():
    entries = []   # (norm_key, persian, pos_int, rank)

    # ---- 1. curated core (function words first = lowest ranks) ----
    priority = {"R": 0, "P": 1, "C": 2, "X": 3, "L": 4, "Q": 5,
                "M": 6, "N": 8, "A": 8, "T": 8, "S": 9, "G": 8, "V": 8}
    for f, p, c in CORE:
        if " " in f:
            continue
        k = normalize_key(f)
        if len(k) < 1:
            continue
        entries.append((k, p, POS_MAP[c], 0, ("core", priority[c])))

    # ---- 2. extra vocabulary ----
    for i, (f, p, c) in enumerate(EXTRA):
        if " " in f:
            continue
        k = normalize_key(f)
        if len(k) < 1:
            continue
        entries.append((k, p, POS_MAP[c], 0, ("extra", 3000 + i)))

    # ---- 2b. V3 vocabulary (user-reported misses, UI words) ----
    # placed between core and extra so these rank higher than 'extra'
    for i, (f, p, c) in enumerate(V3):
        if " " in f:
            continue
        k = normalize_key(f)
        if len(k) < 1:
            continue
        entries.append((k, p, POS_MAP[c], 0, ("v3", 2200 + i)))

    # ---- 3. verb forms (generated, with o->e spelling variants) ----
    for i, (f, p, rank) in enumerate(generate_all()):
        if " " in f:
            continue
        rank = rank
        for var in o_variants(f):
            k = normalize_key(var)
            if len(k) < 1:
                continue
            entries.append((k, p, POS_MAP["V"], rank, ("verb", 2000 + i)))

    # ---- 4. loanwords ----
    for i, (en, fa, fing) in enumerate(parse_loans()):
        k = normalize_key(fing)
        if len(k) < 1:
            continue
        entries.append((k, fa, POS_MAP["T"], 0, ("loan", 800 + i)))
        # english spelling also maps -> persian (typed as english word)
        ke = normalize_key(en)
        if ke != k:
            entries.append((ke, fa, POS_MAP["T"], 0, ("loan-en", 600 + i)))

    # ---- 5. generate plurals for nouns ----
    nouns = [(k, p, r) for (k, p, pos, r, src) in entries
             if pos == POS_MAP["N"] and src[0] in ("core", "v3", "extra")
             and len(p) >= 2 and "\u200c" not in p]
    ZWNJ = "\u200c"
    for k, p, r in nouns:
        pk = k + "ha"
        pp = p + ZWNJ + "ها"
        entries.append((pk, pp, POS_MAP["N"], 0, ("plural", r + 3500)))
        if p.endswith("ه") or p.endswith("ا") or p.endswith("و") or p.endswith("ی"):
            continue
        pk2 = k + "haye"
        pp2 = p + ZWNJ + "های"
        entries.append((pk2, pp2, POS_MAP["N"], 0, ("plural2", r + 4200)))

    # ---- 6. comparatives for adjectives ----
    adjs = [(k, p, r) for (k, p, pos, r, src) in entries
            if pos == POS_MAP["A"] and src[0] in ("core", "v3", "extra")
            and len(p) >= 2 and "\u200c" not in p]
    for k, p, r in adjs:
        sep = ZWNJ if p[-1] in "هاویآ" else ""
        entries.append((k + "tar", p + sep + "تر", POS_MAP["A"],
                        0, ("comp", r + 3800)))
        entries.append((k + "tarin", p + sep + "ترین", POS_MAP["A"],
                        0, ("super", r + 4000)))

    # ---- 7. rank resolution ----
    # rank = explicit (verb forms) OR base + offset within its priority class
    from collections import defaultdict
    buckets = defaultdict(list)
    for e in entries:
        buckets[e[4][0]].append(e)

    ranked = []
    # base offsets per source (lower = more frequent words first);
    # within each source, entries get sequential ranks in insertion order
    from collections import defaultdict
    counter = defaultdict(int)
    base = {"core": 100, "v3": 2200, "extra": 4500, "loan": 900, "loan-en": 950,
            "plural": 5200, "plural2": 7000, "comp": 6200, "super": 6800}
    step = {"core": 1, "v3": 2, "extra": 2, "loan": 2, "loan-en": 2,
            "plural": 1, "plural2": 1, "comp": 2, "super": 2}
    for e in entries:
        src = e[4][0]
        explicit = e[3]
        if src == "verb":
            rank = explicit
        else:
            rank = base[src] + counter[src] * step[src]
            counter[src] += 1
        if rank < 1:
            rank = 1
        ranked.append((e[0], e[1], e[2], rank))

    # ---- 8. dedupe: same (key, persian) -> keep best (lowest) rank ----
    best = {}
    for k, p, pos, r in ranked:
        tag = (k, p)
        if tag not in best or r < best[tag][1]:
            best[tag] = (pos, r)
    rows = [(k, p, pos, r) for (k, p), (pos, r) in best.items()]

    # ---- 9. stats & write ----
    keys = {}
    for k, p, pos, r in rows:
        keys.setdefault(k, []).append((p, pos, r))

    lines = []
    for k, p, pos, r in sorted(rows, key=lambda x: (x[3], x[0])):
        fa = p.replace("\t", " ")
        lines.append(f"{k}\t{fa}\t{pos}\t{r}")
    tsv = "\n".join(lines) + "\n"

    outdir = os.path.join(ROOT, "resources")
    os.makedirs(outdir, exist_ok=True)
    outpath = os.path.join(outdir, "dictionary.tsv")
    io.open(outpath, "w", encoding="utf-8").write(tsv)

    multi = sum(1 for k in keys if len(keys[k]) > 1)
    print(f"entries written : {len(rows)}")
    print(f"unique keys     : {len(keys)}")
    print(f"multi-candidate : {multi}")
    print(f"file            : {outpath}")

    # ---- 10. mandatory checks ----
    assert len(keys) >= 10000, f"FAIL: only {len(keys)} keys (< 10000)"
    for probe, expect in [
        ("dare",  "داره"),
        ("raftam", "رفتم"),
        ("miraftam", "می\u200cرفتم"),
        ("ketab", "کتاب"),
        ("ketabha", "کتاب\u200cها"),
        ("bozorgtar", "بزرگتر"),
        ("sistem", "سیستم"),
        ("tanzimat", "تنظیمات"),
        ("kibord", "کیبورد"),
        ("eslah", "اصلاح"),
        ("irad", "ایراد"),
        ("fnt", "فونت"),
    ]:
        hit = keys.get(normalize_key(probe))
        assert hit, f"FAIL: probe key missing: {probe}"
        fars = [h[0] for h in hit]
        assert expect in fars, f"FAIL: {probe} -> {fars} (missing {expect})"
        print(f"  probe {probe:14s} -> {fars[:3]}")
    print("ALL CHECKS PASSED")

if __name__ == "__main__":
    main()
