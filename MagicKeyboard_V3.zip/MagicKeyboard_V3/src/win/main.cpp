// Magic Keyboard V3 — entry point, hidden window, message loop
#include "app.h"
#include <string>

namespace mkwin {

static HWND g_main = nullptr;

std::wstring ExeDir() {
    wchar_t buf[MAX_PATH + 2]{};
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    std::wstring p(buf);
    size_t slash = p.find_last_of(L"\\/");
    if (slash == std::wstring::npos) return L".\\";
    return p.substr(0, slash + 1);
}

std::string WideToUtf8(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(),
                                nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n,
                        nullptr, nullptr);
    return s;
}

std::wstring Utf8ToWide(const std::string& s8) {
    if (s8.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s8.c_str(), (int)s8.size(),
                                nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s8.c_str(), (int)s8.size(), &w[0], n);
    return w;
}

// ---------------- main window ----------------
static void ToggleEnabled(HWND hwnd) {
    bool on = !HookEnabled();
    HookSetEnabled(on);
    TrayUpdate(on);
    (void)hwnd;
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_APP_TRAY:
            if (lp == WM_LBUTTONDBLCLK) {
                ToggleEnabled(hwnd);
            } else if (lp == WM_RBUTTONUP || lp == WM_CONTEXTMENU) {
                TrayShowMenu(hwnd);
            }
            return 0;

        case WM_APP_SETTINGS:
            ShowSettingsDialog(hwnd);
            return 0;

        case WM_COMMAND:
            switch (LOWORD(wp)) {
                case 1001: ToggleEnabled(hwnd); break;      // فعال/غیرفعال
                case 1002: PostMessageW(hwnd, WM_APP_SETTINGS, 0, 0); break;
                case 1003: {                                 // autostart
                    AppSettings s;
                    SettingsLoad(s);
                    s.autoStart = !s.autoStart;
                    SettingsSave(s);
                    break;
                }
                case 1004: ShowAbout(hwnd); break;
                case 1005: DestroyWindow(hwnd); break;       // خروج
            }
            return 0;

        case WM_DESTROY:
            TrayRemove();
            HookRemove();
            PostQuitMessage(0);
            return 0;
    }
    TrayCheckTaskbar(msg);              // explorer restarted -> re-add icon
    return DefWindowProcW(hwnd, msg, wp, lp);
}

} // namespace mkwin

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
    using namespace mkwin;
    (void)nCmdShow;

    // single instance
    HANDLE mutex = CreateMutexW(nullptr, TRUE, L"MagicKeyboardV3");
    if (GetLastError() == ERROR_ALREADY_EXISTS) return 0;

    // engine + settings
    AppSettings s;
    SettingsLoad(s);
    Engine::inst().init();

    mk::EngineSettings cs;
    cs.loanwordsConvert = s.loanwordsConvert;
    cs.phoneticFallback = s.phoneticFallback;
    cs.protectTechnical = s.protectTechnical;
    Engine::inst().set_core(cs);

    // window class
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_DBLCLKS;              // needed for tray double-click
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"MagicKeyboardV3Wnd";
    wc.hIcon = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(APP_ICON_ON),
                                 IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
    wc.hIconSm = wc.hIcon;
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(0, wc.lpszClassName, L"Magic Keyboard V3",
                                WS_OVERLAPPEDWINDOW, 0, 0, 0, 0,
                                nullptr, nullptr, hInst, nullptr);
    g_main = hwnd;
    (void)g_main;

    if (!Engine::inst().ok()) {
        MessageBoxW(nullptr,
            L"فایل واژه‌نامه (dictionary.tsv) کنار برنامه پیدا نشد!\n"
            L"آن را در همان پوشهٔ MagicKeyboard.exe قرار دهید.",
            L"کیبورد مجیک", MB_OK | MB_ICONERROR | MB_RTLREADING);
    }

    HookInstall(hwnd);
    HookSetEnabled(s.startEnabled);
    TrayInit(hwnd, hInst);
    TrayUpdate(s.startEnabled);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    if (mutex) ReleaseMutex(mutex);
    return 0;
}
