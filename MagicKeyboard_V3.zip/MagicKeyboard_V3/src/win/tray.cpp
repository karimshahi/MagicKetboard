// Magic Keyboard V3 — tray icon (green=ON, gray=OFF) + context menu
#include "app.h"
#include <shellapi.h>

namespace mkwin {

static NOTIFYICONDATAW g_nid{};
static bool g_added = false;

static UINT g_taskbarCreated = 0;

bool TrayInit(HWND hwnd, HINSTANCE hi) {
    g_taskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");

    ZeroMemory(&g_nid, sizeof(g_nid));
    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_APP_TRAY;
    g_nid.hWnd = hwnd;

    bool on = HookEnabled();
    HICON hIcon = (HICON)LoadImageW(hi, MAKEINTRESOURCEW(on ? APP_ICON_ON
                                                           : APP_ICON_OFF),
                                    IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
    g_nid.hIcon = hIcon;
    wchar_t tip[64];
    swprintf(tip, 64, L"کیبورد مجیک ۳ — %s", on ? L"فعال" : L"غیرفعال");
    lstrcpynW(g_nid.szTip, tip, 64);

    g_added = Shell_NotifyIconW(NIM_ADD, &g_nid) != FALSE;
    return g_added;
}

void TrayUpdate(bool on) {
    if (!g_added) return;
    HINSTANCE hi = GetModuleHandleW(nullptr);
    HICON hIcon = (HICON)LoadImageW(hi, MAKEINTRESOURCEW(on ? APP_ICON_ON
                                                           : APP_ICON_OFF),
                                    IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
    if (g_nid.hIcon) DestroyIcon(g_nid.hIcon);
    g_nid.hIcon = hIcon;
    wchar_t tip[64];
    swprintf(tip, 64, L"کیبورد مجیک ۳ — %s", on ? L"فعال" : L"غیرفعال");
    lstrcpynW(g_nid.szTip, tip, 64);
    Shell_NotifyIconW(NIM_MODIFY, &g_nid);
}

void TrayReAdd() {           // explorer restarted
    if (!g_added) return;
    g_added = Shell_NotifyIconW(NIM_ADD, &g_nid) != FALSE;
}

// (TrayReAdd kept for manual use; TrayCheckTaskbar is the automatic path)

void TrayRemove() {
    if (g_added) {
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        g_added = false;
    }
    if (g_nid.hIcon) { DestroyIcon(g_nid.hIcon); g_nid.hIcon = nullptr; }
}

void TrayCheckTaskbar(UINT msg) {
    if (g_added && g_taskbarCreated && msg == g_taskbarCreated) {
        g_added = Shell_NotifyIconW(NIM_ADD, &g_nid) != FALSE;
    }
}

void TrayShowMenu(HWND hwnd) {
    HMENU menu = CreatePopupMenu();
    bool on = HookEnabled();

    AppendMenuW(menu, MF_STRING | (on ? MF_CHECKED : 0), 1001,
                L"فعال (Persian typing)");
    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING, 1002, L"تنظیمات...");
    AppendMenuW(menu, MF_STRING | (SettingsAutoStart() ? MF_CHECKED : 0),
                1003, L"اجرای خودکار با ویندوز");
    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING, 1004, L"درباره کیبورد مجیک");
    AppendMenuW(menu, MF_STRING, 1005, L"خروج");

    POINT pt; GetCursorPos(&pt);
    SetForegroundWindow(hwnd);          // required for tray menus
    TrackPopupMenuEx(menu, TPM_RIGHTBUTTON, pt.x, pt.y, hwnd, nullptr);
    DestroyMenu(menu);
    PostMessageW(hwnd, WM_NULL, 0, 0);
}

} // namespace mkwin
