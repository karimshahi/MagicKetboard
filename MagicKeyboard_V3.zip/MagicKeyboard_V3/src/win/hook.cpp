// Magic Keyboard V2 — global keyboard hook + Unicode injection
//
// Model (same as V1, fixed for V2):
//  * WH_KEYBOARD_LL receives every key. Injected events carry
//    LLKHF_INJECTED and are passed through untouched (no loops).
//  * Letters accumulate into the current word buffer.
//  * On a word boundary (space / enter / punctuation), the buffered word is
//    converted by the V2 engine; if the result differs, Backspaces + the
//    Persian text are injected with SendInput(KEYEVENTF_UNICODE).
//  * The boundary key itself passes through normally, so typing rhythm is
//    preserved.
#include "app.h"
#include <string>
#include <vector>

namespace mkwin {

static HHOOK g_hook = nullptr;
static HWND  g_hwnd = nullptr;
static bool  g_enabled = true;
static std::u32string g_word;              // current word being typed
static std::vector<wchar_t> g_pending;    // output queue for our own injection

// ---------------- helpers ----------------
static bool IsBoundaryKey(WPARAM vk) {
    switch (vk) {
        case VK_SPACE: case VK_RETURN: case VK_TAB: case VK_ESCAPE:
        case VK_BACK: case VK_OEM_1:      // ;
        case VK_OEM_2:                    // /
        case VK_OEM_3:                    // `
        case VK_OEM_4: case VK_OEM_5: case VK_OEM_6: case VK_OEM_7:
        case VK_OEM_COMMA: case VK_OEM_PERIOD: case VK_OEM_MINUS:
        case VK_OEM_PLUS:
            return true;
        default:
            return false;
    }
}

static void SendKeyUnicode(wchar_t ch) {
    INPUT inp{};
    inp.type = INPUT_KEYBOARD;
    inp.ki.wScan = (WORD)ch;
    inp.ki.dwFlags = KEYEVENTF_UNICODE;
    SendInput(1, &inp, sizeof(INPUT));
    INPUT up{};
    up.type = INPUT_KEYBOARD;
    up.ki.wScan = (WORD)ch;
    up.ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
    SendInput(1, &up, sizeof(INPUT));
}

static void SendVk(WORD vk) {
    INPUT dn{}, up{};
    dn.type = INPUT_KEYBOARD; dn.ki.wVk = vk;
    up.type = INPUT_KEYBOARD; up.ki.wVk = vk; up.ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(1, &dn, sizeof(INPUT));
    SendInput(1, &up, sizeof(INPUT));
}

// Replace the last `len` typed characters with `text`.
static void ReplaceWord(size_t len, const std::u32string& text) {
    // backspaces first
    for (size_t i = 0; i < len; ++i) SendVk(VK_BACK);
    // UTF-16 conversion (handles surrogate pairs naturally)
    std::wstring w16;
    for (char32_t cp : text) {
        if (cp <= 0xFFFF) w16 += (wchar_t)cp;
        else {
            cp -= 0x10000;
            w16 += (wchar_t)(0xD800 + (cp >> 10));
            w16 += (wchar_t)(0xDC00 + (cp & 0x3FF));
        }
    }
    for (wchar_t ch : w16) SendKeyUnicode(ch);
}

// Convert the buffered word now (called at boundaries).
static void FlushWord(WPARAM boundaryVk) {
    if (!g_enabled || !Engine::inst().ok() || g_word.empty()) {
        g_word.clear();
        return;
    }
    mk::WordResult r = Engine::inst().cv().convert_word(g_word,
                        Engine::inst().cv().history());
    if (r.action == mk::WordAction::Replace) {
        ReplaceWord(g_word.size(), r.output);
    }
    g_word.clear();
    (void)boundaryVk;
}

// ---------------- the hook itself ----------------
static LRESULT CALLBACK LowLevelProc(int code, WPARAM wParam, LPARAM lParam) {
    if (code == HC_ACTION) {
        KBDLLHOOKSTRUCT* k = (KBDLLHOOKSTRUCT*)lParam;
        bool injected = (k->flags & LLKHF_INJECTED) != 0;

        if (!injected && wParam == WM_KEYDOWN) {
            DWORD vk = k->vkCode;

            if (vk == VK_ESCAPE) {
                g_word.clear();
            } else if (vk == VK_BACK) {
                if (!g_word.empty()) g_word.pop_back();
            } else if (vk >= 'A' && vk <= 'Z') {
                // map through the active layout so Shift/digits act normally
                BYTE ks[256]{}; GetKeyboardState(ks);
                HKL hkl = GetKeyboardLayout(0);
                wchar_t buf[4]{};
                int n = ToUnicodeEx((UINT)vk, k->scanCode, ks, buf, 4, 0, hkl);
                bool isLower = (buf[0] >= L'a' && buf[0] <= L'z');
                bool isUpper = (buf[0] >= L'A' && buf[0] <= L'Z');
                if (n >= 1 && (isLower || isUpper)) {
                    g_word += (char32_t)(isUpper ? buf[0] + 32 : buf[0]);
                } else {
                    FlushWord(0);     // non-letter came through: cut the word
                }
            } else if (vk >= '0' && vk <= '9') {
                FlushWord(0);         // digits cut the word
            } else if (IsBoundaryKey(vk)) {
                FlushWord(vk);
            } else {
                // arrows/function keys etc. — leave the word (do not flush)
            }
        }
    }
    return CallNextHookEx(g_hook, code, wParam, lParam);
}

// ---------------- API ----------------
bool HookInstall(HWND hwnd) {
    g_hwnd = hwnd;
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelProc,
                               GetModuleHandleW(nullptr), 0);
    return g_hook != nullptr;
}

void HookRemove() {
    if (g_hook) { UnhookWindowsHookEx(g_hook); g_hook = nullptr; }
}

void HookSetEnabled(bool enabled) { g_enabled = enabled; }
bool HookEnabled() { return g_enabled; }

std::u32string HookPreviewLastWord() { return g_word; }

} // namespace mkwin
