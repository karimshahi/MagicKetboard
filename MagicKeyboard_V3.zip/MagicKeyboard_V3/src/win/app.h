// Magic Keyboard V2 — Win32 layer: shared app declarations
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shellapi.h>
#include <string>
#include "../core/converter.h"
#include "../core/lexicon.h"
#include "../core/loanwords.h"

namespace mkwin {

// ---------------- resources ----------------
#define APP_ICON_ON    101   // green  (default application icon)
#define APP_ICON_OFF   102   // gray
#define IDD_SETTINGS   201
#define IDC_LW_CONVERT 1001  // checkbox: convert English cognates to Persian
#define IDC_FALLBACK   1002  // checkbox: phonetic fallback
#define IDC_PROTECT    1003  // checkbox: protect technical strings
#define IDC_AUTOSTART  1004  // checkbox: start with Windows
#define IDC_STARTON    1005  // checkbox: start in ON state
#define IDC_ABOUT      1006  // static: about text
#define IDC_PREVIEW    1007  // static: preview text

// ---------------- messages ----------------
#define WM_APP_TRAY      (WM_APP + 1)   // tray icon callback
#define WM_APP_SETTINGS  (WM_APP + 2)   // open settings dialog

// ---------------- settings (persisted in registry) ----------------
struct AppSettings {
    bool loanwordsConvert = true;
    bool phoneticFallback = true;
    bool protectTechnical = true;
    bool autoStart        = false;
    bool startEnabled     = true;
};

bool SettingsLoad(AppSettings& s);
void SettingsSave(const AppSettings& s);
void ApplyAutoStart(bool enabled);
bool SettingsAutoStart();              // for the tray menu checkmark

// ---------------- engine singleton ----------------
class Engine {
public:
    static Engine& inst();
    bool init();                       // load dictionary from exe directory
    const mk::EngineSettings& core() const { return core_; }
    void set_core(const mk::EngineSettings& s) { core_ = s; cv_.set_settings(s); }
    mk::Converter& cv() { return cv_; }
    bool ok() const { return ok_; }
    size_t keyCount() const { return keyCount_; }
private:
    Engine();
    mk::Lexicon lex_;
    mk::LoanwordTable loans_;
    mk::Converter cv_;
    mk::EngineSettings core_;
    bool ok_ = false;
    size_t keyCount_ = 0;
};

// ---------------- hook (hook.cpp) ----------------
bool HookInstall(HWND hwnd);
void HookRemove();
void HookSetEnabled(bool enabled);
bool HookEnabled();
std::u32string HookPreviewLastWord();   // for settings dialog preview

// ---------------- tray (tray.cpp) ----------------
bool TrayInit(HWND hwnd, HINSTANCE hi);
void TrayUpdate(bool on);
void TrayRemove();
void TrayShowMenu(HWND hwnd);
void TrayCheckTaskbar(UINT msg);     // explorer restarted -> re-add icon

// ---------------- dialogs ----------------
void ShowSettingsDialog(HWND parent);
void ShowAbout(HWND parent);

// ---------------- misc ----------------
std::wstring ExeDir();                 // directory of the exe (with trailing \)
std::wstring LoadStrRes(unsigned id);  // not used much; UTF-16 helpers
std::string  WideToUtf8(const std::wstring& w);
std::wstring Utf8ToWide(const std::string& s);

} // namespace mkwin
