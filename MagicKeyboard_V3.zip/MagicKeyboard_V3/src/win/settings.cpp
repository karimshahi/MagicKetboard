// Magic Keyboard V3 — registry-persisted settings + settings dialog
// (user requirement: user can choose whether English words typed inside
//  Persian text are converted to Persian script or kept as English)
//
// V3 FIX (user report: "فونت‌ها کاملاً ناجور هستند" in the settings window):
// The dialog template no longer lives in the .rc file.  It is built in
// memory here and every Persian string is a wide literal from this source
// file, set at runtime with SetDlgItemTextW.  That removes the resource
// compiler from the text path entirely, so the dialog always renders real
// UTF-16 Persian text with a proper Segoe UI 9pt font, right-to-left.
#include "app.h"
#include <string>
#include <vector>

namespace mkwin {

static const wchar_t* kRegKey = L"Software\\MagicKeyboard";

static AppSettings g_settings;
static bool g_settingsLoaded = false;

// ---------------- registry ----------------
static DWORD RegGetDword(HKEY h, const wchar_t* name, DWORD def) {
    DWORD v = def, size = sizeof(DWORD), type = 0;
    if (RegQueryValueExW(h, name, nullptr, &type, (BYTE*)&v, &size)
            != ERROR_SUCCESS || type != REG_DWORD)
        return def;
    return v;
}

bool SettingsLoad(AppSettings& s) {
    HKEY h;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kRegKey, 0, KEY_READ, &h)
            == ERROR_SUCCESS) {
        s.loanwordsConvert = RegGetDword(h, L"LoanwordsConvert", TRUE) != 0;
        s.phoneticFallback = RegGetDword(h, L"PhoneticFallback", TRUE) != 0;
        s.protectTechnical = RegGetDword(h, L"ProtectTechnical", TRUE) != 0;
        s.autoStart        = RegGetDword(h, L"AutoStart",        0)    != 0;
        s.startEnabled     = RegGetDword(h, L"StartEnabled",     TRUE) != 0;
        RegCloseKey(h);
    }
    g_settings = s;
    g_settingsLoaded = true;
    return true;
}

void SettingsSave(const AppSettings& s) {
    HKEY h;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kRegKey, 0, nullptr,
                        REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &h,
                        nullptr) == ERROR_SUCCESS) {
        RegSetValueExW(h, L"LoanwordsConvert", 0, REG_DWORD,
                       (const BYTE*)&s.loanwordsConvert, sizeof(DWORD));
        RegSetValueExW(h, L"PhoneticFallback", 0, REG_DWORD,
                       (const BYTE*)&s.phoneticFallback, sizeof(DWORD));
        RegSetValueExW(h, L"ProtectTechnical", 0, REG_DWORD,
                       (const BYTE*)&s.protectTechnical, sizeof(DWORD));
        RegSetValueExW(h, L"AutoStart", 0, REG_DWORD,
                       (const BYTE*)&s.autoStart, sizeof(DWORD));
        RegSetValueExW(h, L"StartEnabled", 0, REG_DWORD,
                       (const BYTE*)&s.startEnabled, sizeof(DWORD));
        RegCloseKey(h);
    }
    g_settings = s;
    ApplyAutoStart(s.autoStart);
}

bool SettingsAutoStart() {
    return g_settingsLoaded ? g_settings.autoStart : false;
}

void ApplyAutoStart(bool enabled) {
    HKEY h;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
                      L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
                      0, KEY_SET_VALUE, &h) == ERROR_SUCCESS) {
        if (enabled) {
            std::wstring path = ExeDir() + L"MagicKeyboard.exe";
            std::wstring quoted = L"\"" + path + L"\" /silent";
            RegSetValueExW(h, L"MagicKeyboard", 0, REG_SZ,
                           (const BYTE*)quoted.c_str(),
                           (DWORD)((quoted.size() + 1) * sizeof(wchar_t)));
        } else {
            RegDeleteValueW(h, L"MagicKeyboard");
        }
        RegCloseKey(h);
    }
}

// ---------------- engine ----------------
Engine& Engine::inst() {
    static Engine e;
    return e;
}

Engine::Engine() {}

bool Engine::init() {
    // load dictionary.tsv from the exe directory
    std::wstring path = ExeDir() + L"dictionary.tsv";

    HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ,
                           nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
                           nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER sz{};
    GetFileSizeEx(f, &sz);
    std::string tsv;
    tsv.resize((size_t)sz.QuadPart);
    DWORD read = 0;
    ReadFile(f, &tsv[0], (DWORD)tsv.size(), &read, nullptr);
    CloseHandle(f);
    tsv.resize(read);

    size_t n = lex_.load_tsv(tsv);
    cv_.set_lexicon(&lex_);
    cv_.set_loanwords(&loans_);
    ok_ = n > 0;
    keyCount_ = lex_.key_count();
    return ok_;
}

// ---------------- settings dialog ----------------
// in-memory DLGTEMPLATE writer ------------------------------------------
namespace {

struct TplWriter {
    std::vector<WORD> w;
    void word(WORD v)   { w.push_back(v); }
    void dword(DWORD v) {
        w.push_back((WORD)(v & 0xFFFF));
        w.push_back((WORD)(v >> 16));
    }
    // items must start on DWORD boundaries
    void align4() { while (w.size() % 2) word(0); }
    void str(const wchar_t* s) {
        while (*s) word((WORD)*s++);
        word(0);
    }
};

// control styles
constexpr DWORD WS_CHILD_V   = 0x40000000L | 0x10000000L;          // child|visible
constexpr DWORD STY_CHECK    = WS_CHILD_V | 0x00010000L | 0x2;     // +tabstop|autocheck
constexpr DWORD STY_DEFPUSH  = WS_CHILD_V | 0x00010000L | 0x1;     // +tabstop|defpush
constexpr DWORD STY_PUSH     = WS_CHILD_V | 0x00010000L;           // +tabstop
constexpr DWORD STY_STATIC   = WS_CHILD_V;

std::vector<WORD> BuildSettingsTemplate() {
    TplWriter t;
    t.dword(0x80C088C0);        // style: popup|caption|sysmenu|modalframe|center|setfont
    t.dword(0x00402001);        // exstyle: dlgmodalframe | rtlreading | layoutrtl
    t.word(9);                  // cdit: 9 controls
    t.word(0); t.word(0); t.word(150); t.word(76);   // x y cx cy (DLU)
    t.word(0);                  // menu: none
    t.word(0);                  // class: default
    t.word(0);                  // title: empty (set at runtime, RTL-safe)
    t.word(9);                  // point size
    t.str(L"Segoe UI");         // face name — full Persian coverage

    auto item = [&](DWORD style, DWORD exstyle, WORD x, WORD y, WORD cx,
                    WORD cy, WORD id, WORD cls) {
        t.align4();
        t.dword(style);
        t.dword(exstyle);
        t.word(x); t.word(y); t.word(cx); t.word(cy);
        t.word(id);
        t.word(0xFFFF); t.word(cls);          // class atom
        t.word(0);                            // title: empty (runtime text)
        t.word(0);                            // no extra data
    };

    // 5 checkboxes (titles set at runtime)
    item(STY_CHECK,  0x2000 | 0x400000, 10, 10, 280, 12, IDC_LW_CONVERT, 0x0080);
    item(STY_CHECK,  0x2000 | 0x400000, 10, 26, 280, 12, IDC_FALLBACK,   0x0080);
    item(STY_CHECK,  0x2000 | 0x400000, 10, 42, 280, 12, IDC_PROTECT,    0x0080);
    item(STY_CHECK,  0x2000 | 0x400000, 10, 58, 280, 12, IDC_AUTOSTART,  0x0080);
    item(STY_CHECK,  0x2000 | 0x400000, 10, 74, 280, 12, IDC_STARTON,    0x0080);
    // 2 info statics
    item(STY_STATIC, 0x2000 | 0x400000, 10, 92, 280, 10, IDC_ABOUT,      0x0082);
    item(STY_STATIC, 0x2000 | 0x400000, 10, 104, 280, 18, IDC_PREVIEW,   0x0082);
    // buttons
    item(STY_DEFPUSH, 0x2000 | 0x400000, 190, 130, 50, 14, IDOK,         0x0080);
    item(STY_PUSH,    0x2000 | 0x400000, 130, 130, 50, 14, IDCANCEL,     0x0080);
    return t.w;
}

} // namespace

static void SyncControls(HWND dlg, const AppSettings& s) {
    CheckDlgButton(dlg, IDC_LW_CONVERT, s.loanwordsConvert ? BST_CHECKED
                                                          : BST_UNCHECKED);
    CheckDlgButton(dlg, IDC_FALLBACK, s.phoneticFallback ? BST_CHECKED
                                                         : BST_UNCHECKED);
    CheckDlgButton(dlg, IDC_PROTECT, s.protectTechnical ? BST_CHECKED
                                                        : BST_UNCHECKED);
    CheckDlgButton(dlg, IDC_AUTOSTART, s.autoStart ? BST_CHECKED
                                                   : BST_UNCHECKED);
    CheckDlgButton(dlg, IDC_STARTON, s.startEnabled ? BST_CHECKED
                                                    : BST_UNCHECKED);
}

static AppSettings ReadControls(HWND dlg) {
    AppSettings s;
    s.loanwordsConvert = IsDlgButtonChecked(dlg, IDC_LW_CONVERT) != 0;
    s.phoneticFallback = IsDlgButtonChecked(dlg, IDC_FALLBACK) != 0;
    s.protectTechnical = IsDlgButtonChecked(dlg, IDC_PROTECT) != 0;
    s.autoStart        = IsDlgButtonChecked(dlg, IDC_AUTOSTART) != 0;
    s.startEnabled     = IsDlgButtonChecked(dlg, IDC_STARTON) != 0;
    return s;
}

static INT_PTR CALLBACK SettingsProc(HWND dlg, UINT msg, WPARAM wp,
                                     LPARAM lp) {
    switch (msg) {
        case WM_INITDIALOG: {
            SetWindowTextW(dlg, L"تنظیمات کیبورد مجیک ۳");
            // Persian titles for the checkboxes (runtime literals = safe UTF-16)
            SetDlgItemTextW(dlg, IDC_LW_CONVERT,
                L"تبدیل واژه‌های انگلیسی هم‌معنی به فارسی (system ← سیستم)");
            SetDlgItemTextW(dlg, IDC_FALLBACK,
                L"اصلاح هوشمند واژه‌های ناشناخته (غلط تایپی + آوایی)");
            SetDlgItemTextW(dlg, IDC_PROTECT,
                L"دست نزدن به متن فنی (آدرس، کد، نام متغیر)");
            SetDlgItemTextW(dlg, IDC_AUTOSTART,
                L"اجرای خودکار با ویندوز");
            SetDlgItemTextW(dlg, IDC_STARTON,
                L"شروع در حالت فعال (آیکن سبز)");
            SetDlgItemTextW(dlg, IDC_ABOUT,
                L"کیبورد مجیک — نسخهٔ ۳ | تبدیل فینگلیش به فارسی هنگام تایپ");
            SetDlgItemTextW(dlg, IDC_PREVIEW,
                L"نمونه: barname nevis ← برنامه نویس | dare ← داره | "
                L"tanzimat ← تنظیمات | esla ← اصلاح (اصلاح هوشمند)");
            SetDlgItemTextW(dlg, IDOK,   L"تأیید");
            SetDlgItemTextW(dlg, IDCANCEL, L"انصراف");
            SyncControls(dlg, g_settings);
            return TRUE;
        }
        case WM_COMMAND:
            if (LOWORD(wp) == IDOK) {
                AppSettings s = ReadControls(dlg);
                SettingsSave(s);
                mk::EngineSettings cs;
                cs.loanwordsConvert = s.loanwordsConvert;
                cs.phoneticFallback = s.phoneticFallback;
                cs.protectTechnical = s.protectTechnical;
                Engine::inst().set_core(cs);
                EndDialog(dlg, IDOK);
                return TRUE;
            }
            if (LOWORD(wp) == IDCANCEL) {
                EndDialog(dlg, IDCANCEL);
                return TRUE;
            }
            break;
    }
    return FALSE;
}

void ShowSettingsDialog(HWND parent) {
    // dialog template built in memory — no resource-compiler text encoding
    static std::vector<WORD> tpl = BuildSettingsTemplate();
    DialogBoxIndirectParamW(GetModuleHandleW(nullptr),
                            (LPCDLGTEMPLATEW)tpl.data(), parent,
                            SettingsProc, 0);
}

void ShowAbout(HWND parent) {
    MessageBoxW(parent,
        L"کیبورد مجیک — نسخهٔ ۳\n\n"
        "موتور هوشمند تبدیل فینگلیش به فارسی\n"
        "بیش از ۱۱٬۸۰۰ واژه و کلید یکتا\n\n"
        "ویژگی‌های نسخهٔ ۳:\n"
        "• اصلاح هوشمند غلط تایپی (esla ← اصلاح، ktbord ← کیبورد)\n"
        "• پنجرهٔ تنظیمات با فونت درست و چینش راست‌به‌چپ\n"
        "• واژه‌نامهٔ گسترش‌یافته (تنظیمات، ایراد، فونت و…)\n"
        "• آوانگاری بهتر (rah ← راه، robot ← روبوت)\n\n"
        "سبز = فعال | خاکستری = غیرفعال",
        L"درباره کیبورد مجیک", MB_OK | MB_ICONINFORMATION | MB_RTLREADING);
}

} // namespace mkwin
