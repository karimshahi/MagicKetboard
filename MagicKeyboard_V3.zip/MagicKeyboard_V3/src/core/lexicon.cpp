// Magic Keyboard V2 — lexicon implementation
#include "lexicon.h"
#include "string_utils.h"
#include <cstdio>

namespace mk {

size_t Lexicon::load_tsv(const std::string& utf8tsv) {
    size_t loaded = 0;
    size_t pos = 0;
    const size_t n = utf8tsv.size();
    while (pos < n) {
        size_t eol = utf8tsv.find('\n', pos);
        if (eol == std::string::npos) eol = n;
        std::string line = utf8tsv.substr(pos, eol - pos);
        pos = eol + 1;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty() || line[0] == '#') continue;

        // split by \t (4 fields expected)
        std::string f[4]; int fi = 0;
        for (char c : line) {
            if (c == '\t') { if (++fi > 3) break; }
            else f[fi] += c;
        }
        if (f[0].empty() || f[1].empty()) continue;

        Pos p = (Pos)std::stoi(f[2].empty() ? "0" : f[2]);
        uint32_t rank = (uint32_t)std::stoul(f[3].empty() ? "5000" : f[3]);
        add(f[0], utf8_to_utf32(f[1]), p, rank);
        ++loaded;
    }
    return loaded;
}

uint32_t Lexicon::add(const std::string& finglish, const std::u32string& persian,
                      Pos pos, uint32_t rank) {
    std::string key = normalize_finglish_key(finglish);
    if (key.empty() || persian.empty()) return UINT32_MAX;
    uint32_t id = (uint32_t)entries_.size();
    entries_.push_back({normalize_persian(persian), rank, pos});
    index_[key].push_back(id);
    return id;
}

const std::vector<uint32_t>* Lexicon::find(const std::string& normKey) const {
    auto it = index_.find(normKey);
    return it == index_.end() ? nullptr : &it->second;
}

// ---------------- V3 fuzzy correction ----------------
namespace {

// Damerau-Levenshtein with cutoff. Returns true if distance <= maxDist
// (then *dist holds the real distance).
bool edit_distance_capped(const std::string& a, const std::string& b,
                          int maxDist, int* dist) {
    const int la = (int)a.size(), lb = (int)b.size();
    int lenDiff = la > lb ? la - lb : lb - la;
    if (lenDiff > maxDist) return false;

    // classic DP with two rows; early-exit when the row minimum exceeds maxDist
    static int prev_[64], cur_[64];
    if (lb >= 64) return false;
    for (int j = 0; j <= lb; ++j) prev_[j] = j;
    for (int i = 1; i <= la; ++i) {
        cur_[0] = i;
        int rowMin = cur_[0];
        for (int j = 1; j <= lb; ++j) {
            int cost = (a[i - 1] == b[j - 1]) ? 0 : 1;
            int v = prev_[j] + 1;                 // delete
            if (cur_[j - 1] + 1 < v) v = cur_[j - 1] + 1;  // insert
            if (prev_[j - 1] + cost < v) v = prev_[j - 1] + cost;  // sub
            // transposition (adjacent swap)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                int t = prev_[j - 2] + 1;         // counted as 1 op
                if (t < v) v = t;
            }
            cur_[j] = v;
            if (v < rowMin) rowMin = v;
        }
        if (rowMin > maxDist) return false;       // cannot recover
        for (int j = 0; j <= lb; ++j) prev_[j] = cur_[j];
    }
    if (prev_[lb] > maxDist) return false;
    *dist = prev_[lb];
    return true;
}

} // namespace

bool Lexicon::fuzzy_find(const std::string& normKey, int maxDist,
                         uint32_t maxRank, std::vector<uint32_t>* outIds) const {
    outIds->clear();
    if (normKey.size() < 3 || maxDist <= 0) return false;

    std::string bestKey;
    int      bestDist  = maxDist + 1;
    uint32_t bestRank  = UINT32_MAX;
    bool     bestPrefix = false;

    for (const auto& kv : index_) {
        const std::string& key = kv.first;
        // A distance<=2 correction must never span 2 length units:
        // "pesarak"->"pesar" (delete 2) is a real-word ending, not a typo.
        int lenDiff = (int)key.size() - (int)normKey.size();
        if (lenDiff < 0) lenDiff = -lenDiff;
        if (lenDiff > 1 && maxDist <= 2) continue;
        // candidate key must contain a decent word: rank gate
        uint32_t keyBestRank = UINT32_MAX;
        for (uint32_t id : kv.second) {
            uint32_t r = entries_[id].rank;
            if (r < keyBestRank) keyBestRank = r;
        }
        if (keyBestRank > maxRank) continue;

        int d = 0;
        if (!edit_distance_capped(normKey, key, maxDist, &d)) continue;

        // ---- V3.1 fuzzy policy (tuned against real-user regressions) ----
        // d1 + length differs by 1  -> missed/extra letter (ktbord->kibord)
        // d1 + same length + >=5 ch -> substitution in a long-enough word
        // d2 + same length + >=7 ch + common word -> double slip
        // Everything else is too ambiguous (esm~elm, pesarak~pesarha) and
        // falls through to the phonetic layer, which handles it well.
        if (d == 1) {
            if (!(lenDiff == 1 || (lenDiff == 0 && key.size() >= 5)))
                continue;
        } else if (d == 2) {
            if (!(lenDiff == 0 && key.size() >= 7 && keyBestRank <= 3000))
                continue;
        } else {
            continue;
        }

        // truncated typing: "esla" is a prefix of "eslah" — the most
        // common real-world slip. Prefer it over an equal-distance but
        // unrelated common word ("esla" vs "ela").
        bool prefix = normKey.size() < key.size()
                   && key.compare(0, normKey.size(), normKey) == 0;

        bool better = false;
        if (d < bestDist) better = true;
        else if (d == bestDist) {
            if (prefix && !bestPrefix) better = true;
            else if (prefix == bestPrefix && keyBestRank < bestRank) better = true;
        }
        if (better) {
            bestDist   = d;
            bestRank   = keyBestRank;
            bestKey    = key;
            bestPrefix = prefix;
        }
    }
    if (bestKey.empty()) return false;
    *outIds = index_.find(bestKey)->second;
    return true;
}

} // namespace mk
