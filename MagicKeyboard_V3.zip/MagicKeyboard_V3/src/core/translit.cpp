// Magic Keyboard V2 — phonetic fallback implementation
#include "translit.h"
#include "string_utils.h"
#include <vector>
#include <unordered_map>

namespace mk {

// Longest-match rule table.
struct Rule { const char* lat; std::u32string fa; };

static std::u32string U(const char* utf8) { return utf8_to_utf32(utf8); }

static const std::vector<Rule>& rules() {
    static const std::vector<Rule> r = {
        // digraph consonants
        {"kh", U("\xD8\xAE")}, {"gh", U("\xD8\xBA")}, {"sh", U("\xD8\xB4")},
        {"ch", U("\xDA\x86")}, {"zh", U("\xDA\x98")}, {"th", U("\xD8\xAA")},
        {"ph", U("\xD9\x81")}, {"ck", U("\xDA\xA9")},
        // vowel digraphs
        {"aa", U("\xD8\xA7")}, {"ee", U("\xDB\x8C")}, {"oo", U("\xD9\x88")},
        {"ou", U("\xD9\x88")}, {"ow", U("\xD9\x88")}, {"au", U("\xD9\x88")},
        {"ay", U("\xD8\xA7\xDB\x8C")}, {"ey", U("\xD8\xA7\xDB\x8C")},
        {"ai", U("\xD8\xA7\xDB\x8C")}, {"ei", U("\xD8\xA7\xDB\x8C")},
        {"ea", U("\xD8\xA7")}, {"eu", U("\xD9\x88")},
        // consonants
        {"b", U("\xD8\xA8")}, {"p", U("\xD9\xBE")}, {"t", U("\xD8\xAA")},
        {"s", U("\xD8\xB3")}, {"j", U("\xD8\xAC")}, {"f", U("\xD9\x81")},
        {"g", U("\xDA\xAF")}, {"l", U("\xD9\x84")}, {"m", U("\xD9\x85")},
        {"n", U("\xD9\x86")}, {"v", U("\xD9\x88")}, {"h", U("\xD9\x87")},
        {"k", U("\xDA\xA9")}, {"q", U("\xD9\x82")}, {"w", U("\xD9\x88")},
        {"x", U("\xD8\xAE")}, {"z", U("\xD8\xB2")}, {"c", U("\xDA\xA9")},
        {"r", U("\xD8\xB1")}, {"d", U("\xD8\xAF")},
        // y handled specially (initial = ی, medial = ی)
    };
    return r;
}

bool phonetic_translit(const std::u32string& raw, std::u32string* out) {
    // lowercase ASCII copy
    std::u32string s;
    for (char32_t c : raw) {
        if (c >= U'A' && c <= U'Z') c += 32;
        if (c >= U'a' && c <= U'z') s += c;
        else return false;                    // digits/apostrophes: bail out
    }
    if (s.empty() || s.size() > 20) return false;

    const auto& R = rules();
    std::u32string res;
    size_t i = 0, n = s.size();
    bool firstVowelDone = false;
    while (i < n) {
        char32_t c = s[i];

        // ---- vowel policy: short vowels a/e are usually NOT written in
        // Persian except word-initially or word-finally.
        auto isShort = [&](char32_t v) { return v == U'a' || v == U'e'; };

        if (isShort(c)) {
            bool atStart = (i == 0);
            bool atEnd   = (i == n - 1);
            // look ahead: 'e'/'a' at very end -> ه / ا
            if (atEnd) {
                res += (c == U'e') ? U("\xD9\x87") : U("\xD8\xA7");
                ++i; continue;
            }
            if (atStart) { res += U("\xD8\xA7"); ++i; continue; }
            // before a word-final consonant that reads as a real letter:
            //   "rah" -> راه ,  "tanzimat" -> تنظیمات  (V3 fixes)
            if (c == U'a' && i == n - 2) {
                char32_t last = s[n - 1];
                if (last == U'h' || last == U't') {
                    res += U("\xD8\xA7");   // write the 'a'
                    ++i;                    // keep last letter (h->ه / t->ت)
                    continue;
                }
            }
            ++i; continue;                        // silent short vowel
        }

        // ---- V3: 'o' is a REAL vowel in Persian orthography (کیبورد، روبوت):
        // word-initial -> ا , otherwise -> و
        if (c == U'o') {
            res += (i == 0) ? U("\xD8\xA7") : U("\xD9\x88");
            ++i; continue;
        }

        // ---- V3: word-initial 'i' reads as ای (ایراد، ایران):
        if (c == U'i' && i == 0) { res += U("\xD8\xA7\xDB\x8C"); ++i; continue; }

        if (c == U'i') { res += U("\xDB\x8C"); ++i; continue; }
        if (c == U'u') { res += U("\xD9\x88"); ++i; continue; }
        if (c == U'y') { res += U("\xDB\x8C"); ++i; continue; }

        // longest-match against rules
        bool matched = false;
        size_t bestLen = 0; const std::u32string* bestFa = nullptr;
        for (const Rule& r : R) {
            size_t len = 0; while (r.lat[len]) ++len;
            if (len <= bestLen || len > n - i) continue;
            bool eq = true;
            for (size_t k = 0; k < len; ++k)
                if (s[i + k] != (char32_t)r.lat[k]) { eq = false; break; }
            if (eq) { bestLen = len; bestFa = &r.fa; }
        }
        if (bestFa) { res += *bestFa; i += bestLen; matched = true; }
        if (!matched) return false;               // unknown letter
        (void)firstVowelDone;
    }
    *out = res;
    return !res.empty();
}

} // namespace mk
