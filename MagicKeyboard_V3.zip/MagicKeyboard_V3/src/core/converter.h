// Magic Keyboard V2 — conversion pipeline
// Single word (used by the Windows hook at word boundaries) and full lines
// (used by tests and the settings preview).
#pragma once
#include "types.h"
#include "context.h"
#include <string>
#include <vector>

namespace mk {

class Lexicon;

class Converter {
public:
    Converter();

    void set_lexicon(const Lexicon* lex)          { lex_ = lex; }
    void set_loanwords(const class LoanwordTable* lw) { loanwords_ = lw; }
    void set_settings(const EngineSettings& s)    { settings_ = s; }
    EngineSettings settings() const               { return settings_; }

    // Convert one raw typed word, given the left context (previously typed
    // words). The hook calls this at every word boundary.
    WordResult convert_word(const std::u32string& raw,
                            const std::vector<ContextWord>& prev);

    // Convert a whole line (tokenizes + keeps separators verbatim).
    std::u32string convert_line(const std::u32string& line);

    // rolling history of the last converted words (context for the next word)
    const std::vector<ContextWord>& history() const { return history_; }
    void reset_history() { history_.clear(); }

    // Exposed for tests
    const LoanwordTable* loanwords() const { return loanwords_; }

private:
    const Lexicon* lex_ = nullptr;
    const LoanwordTable* loanwords_ = nullptr;
    EngineSettings settings_;
    ContextEngine ctx_;
    std::vector<ContextWord> history_;

    bool dict_lookup(const std::string& normKey, std::u32string* out,
                     uint32_t* rank, Pos* pos, void* user);
    static bool dict_lookup_thunk(const std::string& k, std::u32string* o,
                                  uint32_t* r, Pos* p, void* user);
    void push_history(const std::u32string& text, Pos pos);
    double confidence_for_rank(uint32_t rank) const;
};

} // namespace mk
