// Magic Keyboard V2 — context engine implementation
#include "context.h"
#include "lexicon.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace mk {

static bool is_verbish(Pos p)  { return p == Pos::Verb || p == Pos::Aux; }
static bool is_nominal(Pos p)  { return p == Pos::Noun || p == Pos::Adj ||
                                        p == Pos::Num  || p == Pos::Name; }
static bool subject_like(Pos p){ return p == Pos::Pron || p == Pos::Noun ||
                                        p == Pos::Name || p == Pos::Num  ||
                                        p == Pos::Adj || p == Pos::General; }

double ContextEngine::effective_rank(const LexEntry& cand, const ContextWord* prev) const {
    double r = (double)cand.rank;
    if (!prev) return r;

    // Rule 1: verb/auxiliary right after a subject-like word -> strong boost.
    //   "man dare ..." / "ali dare ..."  => داره, not دره
    if (is_verbish(cand.pos) && subject_like(prev->pos))
        r *= 0.30;

    // Rule 2: verb/auxiliary right after a preposition -> heavy penalty.
    //   "az dare ..." => دره (valley), never the auxiliary
    if (is_verbish(cand.pos) && prev->pos == Pos::Prep)
        r *= 6.0;

    // Rule 3: nominal right after a preposition -> boost.
    if (is_nominal(cand.pos) && prev->pos == Pos::Prep)
        r *= 0.45;

    // Rule 4: preposition following a preposition -> penalty.
    if (cand.pos == Pos::Prep && prev->pos == Pos::Prep)
        r *= 5.0;

    // Rule 5: auxiliary right after another auxiliary/verb -> penalty.
    //   ("dare bere" typed as two words: second word likely not another aux)
    if (is_verbish(cand.pos) && is_verbish(prev->pos))
        r *= 2.2;

    // Rule 6: colloquial form right after formal verb is fine; formal verb
    // right after colloquial aux is normal too — no rule needed.

    return r;
}

uint32_t ContextEngine::pick(const Lexicon& lex,
                             const std::vector<uint32_t>& ids,
                             const std::vector<ContextWord>& prevWords,
                             uint32_t* plainTop) const {
    if (ids.empty()) return UINT32_MAX;

    // plain-rank top (what V1 would have chosen *after* the rank fix)
    uint32_t top = ids[0];
    for (uint32_t id : ids)
        if (lex.entry(id).rank < lex.entry(top).rank) top = id;
    if (plainTop) *plainTop = top;

    const ContextWord* prev = prevWords.empty() ? nullptr : &prevWords.back();

    // context-adjusted best
    uint32_t best = top;
    double bestRank = std::numeric_limits<double>::max();
    for (uint32_t id : ids) {
        double r = effective_rank(lex.entry(id), prev);
        // stable tie-break: rank, then id order (dictionary insertion priority)
        if (r < bestRank) { bestRank = r; best = id; }
    }
    return best;
}

} // namespace mk
