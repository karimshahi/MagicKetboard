// Magic Keyboard V2 — suffix engine implementation
#include "suffix.h"
#include "string_utils.h"
#include <vector>
#include <algorithm>

namespace mk {

struct Clitic {
    const char* key;          // normalized suffix (on the NORMALIZED key)
    const char* persian;      // suffix text in Persian
    bool        zwnjBefore;   // insert ZWNJ between stem and suffix?
    const char* kind;
    Pos         mustBe;       // required stem pos (General = any)
};

// Ordered longest-first. Normalized key space (aa->a etc.) matches stems.
static const Clitic kClitics[] = {
    // plural + ezafe variants
    {"haha",   "\xD9\x87\xD8\xA7", true,  "plural",      Pos::General}, // haha? no — skip, listed for safety
    {"ha",     "\xD9\x87\xD8\xA7", true,  "plural",      Pos::General}, // ها
    {"haye",   "\xD9\x87\xD8\xA7\xDB\x8C", true, "plural", Pos::General}, // های
    {"hayam",  "\xD9\x87\xD8\xA7\xDB\x8C\xD9\x85", true, "plural", Pos::General}, // هایم
    // possessive / verb endings (attached, no ZWNJ)
    {"ashan",  "\xD8\xB4\xD8\xA7\xD9\x86", false, "possessive", Pos::General}, // شان
    {"eman",   "\xD8\xB4\xD8\xA7\xD9\x86", false, "possessive", Pos::General},
    {"etan",   "\xD8\xAA\xD8\xA7\xD9\x86", false, "possessive", Pos::General},
    {"aman",   "\xD9\x85\xD8\xA7\xD9\x86", false, "possessive", Pos::General},
    {"ash",    "\xD8\xB4", false, "possessive", Pos::General},   // ش
    {"esh",    "\xD8\xB4", false, "possessive", Pos::General},
    {"am",     "\xD9\x85", false, "possessive", Pos::General},   // م
    {"at",     "\xD8\xAA", false, "possessive", Pos::General},   // ت
    {"et",     "\xD8\xAA", false, "possessive", Pos::General},
    // comparatives
    {"tarin",  "\xD8\xAA\xD8\xB1\xDB\x8C\xD9\x86", false, "comparative", Pos::Adj}, // ترین
    {"tar",    "\xD8\xAA\xD8\xB1", false, "comparative", Pos::Adj},           // تر
};

SuffixSplit SuffixEngine::split(const std::string& rawWord) const {
    SuffixSplit out;
    std::string key = normalize_finglish_key(rawWord);
    if (key.size() < 5) return out;               // too short to split safely

    for (const Clitic& c : kClitics) {
        size_t clen = 0; while (c.key[clen]) ++clen;
        if (key.size() <= clen + 1) continue;     // stem must keep >=2 chars
        if (key.compare(key.size() - clen, clen, c.key) != 0) continue;

        std::string stemKey = key.substr(0, key.size() - clen);
        std::u32string stemFa; uint32_t rank; Pos pos;
        if (!lookup_(stemKey, &stemFa, &rank, &pos, user_)) continue;
        if (c.mustBe != Pos::General && pos != c.mustBe) continue;
        // avoid nonsense like "khane" + "ha" twice or verb stems with possessive
        if (pos == Pos::Verb && std::string(c.kind) != "verb") continue;

        std::u32string suf = utf8_to_utf32(c.persian);
        out.persian = stemFa;
        if (c.zwnjBefore) out.persian += ZWNJ;
        out.persian += suf;
        out.ok = true;
        out.stemRank = rank;
        out.kind = c.kind;
        return out;
    }
    return out;
}

} // namespace mk
