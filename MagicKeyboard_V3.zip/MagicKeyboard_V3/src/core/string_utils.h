// Magic Keyboard V2 — string utilities (UTF-8 <-> UTF-32, normalization)
#pragma once
#include <string>
#include <string_view>
#include <vector>
#include "types.h"

namespace mk {

// ---------- UTF conversions ----------
std::string  utf32_to_utf8(const std::u32string& s);
std::u32string utf8_to_utf32(const std::string& s);

// ---------- Finglish key normalization ----------
// Lowercase ASCII; map x->kh, ck->k; collapse aa->a, ee->i, oo->u; strip non a-z0-9.
// Example: "Khaanee" -> "khani", "Xeili" -> "khili"
std::string normalize_finglish_key(const std::u32string& raw);
std::string normalize_finglish_key(const std::string& utf8raw);

// ---------- Persian text normalization ----------
// Arabic yeh/kaf -> Persian; strip diacritics; collapse tatweel.
std::u32string normalize_persian(const std::u32string& s);

// Split a line into word tokens and separators.
// A token is a maximal run of [A-Za-z0-9'] plus Persian/Arabic letters.
// Everything else (spaces, punctuation, newlines) is passed through verbatim.
struct Token {
    enum Kind { Word, Sep } kind;
    std::u32string text;
};
std::vector<Token> tokenize(const std::u32string& line);

// True if the token contains only ASCII letters/digits/typical code chars.
bool looks_ascii(const std::u32string& s);

// Heuristics (V1 kept): url / email / path / camelCase / ALL-CAPS / digit-led
bool looks_technical(const std::u32string& word);

} // namespace mk
