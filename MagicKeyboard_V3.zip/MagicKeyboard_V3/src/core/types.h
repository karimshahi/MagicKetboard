// Magic Keyboard V2 — core types
// Portable (no Windows dependency). C++17.
// V2 additions: loanword policy, engine settings, richer WordResult, context hints.
#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <unordered_map>

namespace mk {

// A Unicode code point stored as UTF-32 while processing.
using CP = char32_t;

// Persian-specific code points
constexpr CP ZWNJ        = U'\u200C'; // نیم‌فاصله
constexpr CP ARABIC_YEH  = U'\u064A'; // ي (Arabic yeh — we normalize away)
constexpr CP PERSIAN_YEH = U'\u06CC'; // ی
constexpr CP ARABIC_KAF  = U'\u0643'; // ك (Arabic kaf — normalize away)
constexpr CP PERSIAN_KAF = U'\u06A9'; // ک
constexpr CP HEH         = U'\u0647'; // ه
constexpr CP TATWEEL     = U'\u0640'; // ـ

// Diacritic marks (اعراب) — stripped on lookup
constexpr CP FATHA = U'\u064E';
constexpr CP KASRA = U'\u0650';
constexpr CP DAMMA = U'\u064F';
constexpr CP SUKUN = U'\u0652';
constexpr CP TANVIN_FATHA = U'\u064B';
constexpr CP TASHDID = U'\u0651';

// Result of converting one word.
enum class WordAction {
    Keep,     // leave the Latin text as typed
    Replace   // replace with `output`
};

struct WordResult {
    WordAction action = WordAction::Keep;
    std::u32string output;      // replacement text (UTF-32), valid when Replace
    double confidence = 0.0;    // 0..1
    // V2 diagnostics — why this decision was made:
    //  "dict"          exact dictionary hit
    //  "context"       dictionary hit, candidate chosen by context rules
    //  "suffix"        stem + clitic split (ketabam -> کتابم)
    //  "loanword"      English-Persian cognate (system -> سیستم)
    //  "loanword-kept" cognate but policy says keep English
    //  "english"       protected English word
    //  "no-match"      unknown word (kept) — phonetic fallback may still fire
    //  "phonetic"      rule-based transliteration fallback
    //  "disabled"      engine off
    const char* reason = "";
};

// Part-of-speech tags (stored compactly in the dictionary)
enum class Pos : uint8_t {
    General = 0,   // عمومی
    Noun    = 1,   // اسم
    Adj     = 2,   // صفت
    Verb    = 3,   // فعل (صرف‌شده)
    Aux     = 4,   // فعل کمکی/حال محاوره‌ای (داره، می‌شه ...)
    Prep    = 5,   // حرف اضافه
    Pron    = 6,   // ضمیر
    Conj    = 7,   // حرف ربط
    Adv     = 8,   // قید
    Num     = 9,   // عدد
    Colloq  = 10,  // محاوره‌ای
    Name    = 11,  // اسم خاص
    Tech    = 12   // اصطلاح فنی
};

// A dictionary entry
struct LexEntry {
    std::u32string word;   // canonical Persian (may contain ZWNJ)
    uint32_t rank = 0;     // 1 = most frequent (lower = more frequent)
    Pos      pos  = Pos::General;
};

// One line of engine settings (persisted by the platform layer).
struct EngineSettings {
    // V2: what to do with English words that have the same spelling AND meaning
    // in Persian (system/سیستم، test/تست، film/فیلم ...):
    //   true  -> type them as Persian script (سیستم)
    //   false -> keep them as English ("system")
    bool loanwordsConvert = true;

    // Conservative AutoCorrect: only fix words with a unique high-rank match
    // when the typed form is off by one char. (V1 behavior kept)
    bool autoCorrect = true;

    // Phonetic fallback for words missing from the dictionary.
    bool phoneticFallback = true;

    // Protect things that look like code/urls/emails/paths.
    bool protectTechnical = true;
};

// Finglish key -> list of candidate entries (scored at query time)
struct KeyHit {
    uint32_t entry_id;
    double  score;
};

enum class UiLang : uint8_t { Fa = 0, En = 1 };

} // namespace mk
