// Magic Keyboard V2 — conversion pipeline implementation
#include "converter.h"
#include "lexicon.h"
#include "loanwords.h"
#include "suffix.h"
#include "translit.h"
#include "string_utils.h"
#include <algorithm>

namespace mk {

Converter::Converter() {
    // V2 defaults (user requirements):
    settings_.loanwordsConvert  = true;
    settings_.autoCorrect       = true;
    settings_.phoneticFallback  = true;
    settings_.protectTechnical  = true;
}

bool Converter::dict_lookup(const std::string& normKey, std::u32string* out,
                            uint32_t* rank, Pos* pos, void* /*user*/) {
    if (!lex_) return false;
    const std::vector<uint32_t>* hits = lex_->find(normKey);
    if (!hits || hits->empty()) return false;
    // best pure-rank entry for stem lookups
    uint32_t top = hits->front();
    for (uint32_t id : *hits)
        if (lex_->entry(id).rank < lex_->entry(top).rank) top = id;
    const LexEntry& e = lex_->entry(top);
    if (out)  *out  = e.word;
    if (rank) *rank = e.rank;
    if (pos)  *pos  = e.pos;
    return true;
}

bool Converter::dict_lookup_thunk(const std::string& k, std::u32string* o,
                                  uint32_t* r, Pos* p, void* user) {
    // thunk: recover `this` from the Converter address (suffix engine is a member)
    return reinterpret_cast<Converter*>(user)->dict_lookup(k, o, r, p, user);
}

void Converter::push_history(const std::u32string& text, Pos pos) {
    history_.push_back({text, pos});
    if (history_.size() > 4) history_.erase(history_.begin());
}

double Converter::confidence_for_rank(uint32_t rank) const {
    if (rank <= 100)   return 0.97;
    if (rank <= 500)   return 0.92;
    if (rank <= 2000)  return 0.85;
    if (rank <= 8000)  return 0.72;
    return 0.55;
}

WordResult Converter::convert_word(const std::u32string& raw,
                                  const std::vector<ContextWord>& prev) {
    WordResult res;
    if (raw.empty()) { res.reason = "no-match"; return res; }

    // Already Persian? leave untouched.
    bool hasPersian = false;
    for (char32_t c : raw)
        if (c >= 0x0600 && c <= 0x06FF) { hasPersian = true; break; }
    if (hasPersian) { res.reason = "english"; return res; }

    // technical strings are always protected
    if (settings_.protectTechnical && looks_technical(raw)) {
        res.reason = "english";
        return res;
    }

    // must start with a letter to be convertible
    char32_t c0 = raw[0];
    bool letter0 = ((c0 >= U'a' && c0 <= U'z') || (c0 >= U'A' && c0 <= U'Z'));
    if (!letter0) { res.reason = "no-match"; return res; }

    // ---- 1. English-Persian cognates (V2) -------------------------------
    if (loanwords_ && looks_ascii(raw)) {
        const LoanwordEntry* lw = loanwords_->find(raw);
        if (lw) {
            if (settings_.loanwordsConvert) {
                res.action = WordAction::Replace;
                res.output = utf8_to_utf32(lw->persian);
                res.confidence = 0.90;
                res.reason = "loanword";
                push_history(res.output, Pos::Tech);
                return res;
            }
            res.action = WordAction::Keep;
            res.confidence = 0.90;
            res.reason = "loanword-kept";
            return res;
        }
    }

    // ---- 2. dictionary with context-aware candidate pick ----------------
    std::string key = normalize_finglish_key(raw);
    if (!key.empty() && lex_) {
        const std::vector<uint32_t>* hits = lex_->find(key);
        if (hits && !hits->empty()) {
            uint32_t plainTop = hits->front();
            uint32_t chosen = ctx_.pick(*lex_, *hits, prev, &plainTop);
            const LexEntry& e = lex_->entry(chosen);
            res.action = WordAction::Replace;
            res.output = e.word;
            res.confidence = confidence_for_rank(e.rank);
            res.reason = (chosen != plainTop) ? "context" : "dict";
            push_history(res.output, e.pos);
            return res;
        }
    }

    // ---- 3. stem + clitic split (ketabam -> کتابم) ----------------------
    if (lex_ && key.size() >= 5) {
        SuffixEngine se(&Converter::dict_lookup_thunk, this);
        SuffixSplit sp = se.split(utf32_to_utf8(raw));
        if (sp.ok) {
            res.action = WordAction::Replace;
            res.output = sp.persian;
            res.confidence = 0.78;
            res.reason = "suffix";
            push_history(res.output, Pos::General);
            return res;
        }
    }

    // ---- 4. common English words must survive ---------------------------
    static const char* kEnStop[] = {
        "the","a","an","is","are","am","was","were","be","been","to","of","in",
        "on","at","for","and","or","but","if","then","this","that","these",
        "those","it","its","as","by","with","from","has","have","had","do",
        "does","did","not","no","yes","so","we","you","they","he","she","his",
        "her","their","our","my","your","me","him","them","us","will","can",
        "just","about","there","here","what","when","where","who","how","why",
        "all","any","some","one","two","get","got","go","went","make","made",
        "see","seen","know","knew","think","want","need","time","like","also",
        nullptr };
    std::u32string rawLower;
    for (char32_t c : raw)
        rawLower += (c >= U'A' && c <= U'Z') ? (c + 32) : c;
    std::string rawLower8 = utf32_to_utf8(rawLower);
    for (int i = 0; kEnStop[i]; ++i) {
        if (rawLower8 == kEnStop[i]) {
            res.reason = "english";
            return res;
        }
    }

    // ---- 4.5 fuzzy dictionary correction (V3) ---------------------------
    // Tries to fix slips of the finger against the lexicon itself:
    //   esla -> eslah (اصلاح), ktbord -> kibord (کیبورد), tanzimatt -> تنظیمات
    // Conservative gates:
    //   * distance 1 for short words, distance 2 only for len>=7 AND the
    //     candidate length within 1 char (so pesarak never collapses to pesar)
    //   * candidate must be reasonably frequent (rank gate)
    //   * disabled together with the phonetic toggle (same "unknown word"
    //     policy — user may want untouched Latin)
    if (lex_ && settings_.phoneticFallback && settings_.autoCorrect
            && key.size() >= 4) {          // <4: too ambiguous for fuzzy
        int      maxDist = (key.size() >= 7) ? 2 : 1;
        uint32_t maxRank = 9000u;   // any reasonably common dictionary word
        std::vector<uint32_t> ids;
        if (lex_->fuzzy_find(key, maxDist, maxRank, &ids)) {
            uint32_t plainTop = ids.front();
            uint32_t chosen = ctx_.pick(*lex_, ids, prev, &plainTop);
            const LexEntry& e = lex_->entry(chosen);
            res.action = WordAction::Replace;
            res.output = e.word;
            res.confidence = confidence_for_rank(e.rank);
            res.confidence *= (maxDist == 1) ? 0.85 : 0.65;
            if (res.confidence > 0.90) res.confidence = 0.90;
            res.reason = "fuzzy";
            push_history(res.output, e.pos);
            return res;
        }
    }

    // ---- 5. phonetic fallback (V2: toggleable) --------------------------
    if (settings_.phoneticFallback) {
        std::u32string out;
        if (phonetic_translit(raw, &out)) {
            res.action = WordAction::Replace;
            res.output = out;
            res.confidence = 0.35;
            res.reason = "phonetic";
            push_history(res.output, Pos::General);
            return res;
        }
    }

    res.reason = "no-match";
    return res;
}

std::u32string Converter::convert_line(const std::u32string& line) {
    std::u32string out;
    history_.clear();
    for (const Token& t : tokenize(line)) {
        if (t.kind == Token::Sep) { out += t.text; continue; }
        WordResult r = convert_word(t.text, history_);
        if (r.action == WordAction::Replace) out += r.output;
        else out += t.text;
    }
    return out;
}

} // namespace mk
