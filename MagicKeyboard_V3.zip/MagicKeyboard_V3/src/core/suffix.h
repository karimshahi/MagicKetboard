// Magic Keyboard V2 — suffix / clitic splitter
// Unknown word "ketabam" -> stem "ketab" (کتاب) + clitic "am" (م) => «کتابم»
// Also plurals ("ketabha" -> کتاب‌ها) and comparative ("bozorgtar" -> بزرگتر).
#pragma once
#include "types.h"
#include <string>

namespace mk {

struct SuffixSplit {
    bool        ok = false;
    std::u32string persian;     // composed output (stem + suffix)
    uint32_t    stemRank = 0;   // rank of the matched stem
    const char* kind = "";      // "plural", "possessive", "comparative", "verb"
};

class SuffixEngine {
public:
    // `try_convert` looks up a candidate stem; returns true if found and sets
    // outPersian/stemRank/pos. Implemented by the converter to avoid a
    // circular dependency.
    using StemLookup = bool (*)(const std::string& normKey,
                                std::u32string* outPersian,
                                uint32_t* outRank,
                                Pos* outPos,
                                void* user);
    SuffixEngine(StemLookup lookup, void* user) : lookup_(lookup), user_(user) {}

    SuffixSplit split(const std::string& rawWord) const;

private:
    StemLookup lookup_;
    void* user_;
};

} // namespace mk
