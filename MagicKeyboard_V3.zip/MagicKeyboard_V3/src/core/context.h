// Magic Keyboard V2 — context-aware candidate selection
// Fixes V1 bug: typing "dare" picked «دره» (valley) instead of «داره» (has/does).
// Strategy: candidates are scored by frequency rank, adjusted by the previous
// word's part-of-speech (the word being typed is not complete yet, so only
// LEFT context exists at typing time).
#pragma once
#include "types.h"
#include <vector>

namespace mk {

struct ContextWord {
    std::u32string text;   // Persian output of that word
    Pos pos;               // its part of speech (General if unknown)
};

class ContextEngine {
public:
    // Pick the best candidate id from `ids` (all valid hits for one key).
    // `plainTop` is the id the pure-rank ordering would choose.
    // Returns the chosen id.
    uint32_t pick(const class Lexicon& lex,
                  const std::vector<uint32_t>& ids,
                  const std::vector<ContextWord>& prevWords,
                  uint32_t* plainTop) const;

    // Effective rank of a candidate given left context (lower = better).
    double effective_rank(const LexEntry& cand, const ContextWord* prev) const;
};

} // namespace mk
