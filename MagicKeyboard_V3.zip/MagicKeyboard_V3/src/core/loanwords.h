// Magic Keyboard V2 — English-Persian cognates (وام‌واژه‌ها)
// Words that are written the same in English AND used in Persian with the
// same meaning: system/سیستم، test/تست، film/فیلم ...
//
// V2 behavior (user requirement):
//   * Persian mode + settings.loanwordsConvert == true
//       -> typing "system" produces «سیستم»
//   * Persian mode + settings.loanwordsConvert == false
//       -> "system" stays English
#pragma once
#include "types.h"
#include <string>
#include <vector>
#include <unordered_map>

namespace mk {

struct LoanwordEntry {
    const char* english;   // exact lowercase English spelling
    const char* persian;   // Persian script output (UTF-8)
    const char* finglish;  // finglish spelling (registered into main dictionary too)
};

class LoanwordTable {
public:
    LoanwordTable();                        // builds from kTable below
    // nullptr when not a known cognate
    const LoanwordEntry* find(const std::u32string& asciiWord) const;
    const std::vector<LoanwordEntry>& all() const { return table_; }
private:
    std::vector<LoanwordEntry> table_;
    std::unordered_map<std::u32string, size_t> index_;
};

} // namespace mk
