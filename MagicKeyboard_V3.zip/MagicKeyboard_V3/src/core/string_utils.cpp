// Magic Keyboard V2 — string utilities implementation
#include "string_utils.h"
#include <unordered_map>
#include <algorithm>
#include <cstdint>

namespace mk {

// ---------------- UTF-8 <-> UTF-32 ----------------
static void append_utf8(std::string& out, char32_t cp) {
    if (cp < 0x80) out += (char)cp;
    else if (cp < 0x800) {
        out += (char)(0xC0 | (cp >> 6));
        out += (char)(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        out += (char)(0xE0 | (cp >> 12));
        out += (char)(0x80 | ((cp >> 6) & 0x3F));
        out += (char)(0x80 | (cp & 0x3F));
    } else {
        out += (char)(0xF0 | (cp >> 18));
        out += (char)(0x80 | ((cp >> 12) & 0x3F));
        out += (char)(0x80 | ((cp >> 6) & 0x3F));
        out += (char)(0x80 | (cp & 0x3F));
    }
}

std::string utf32_to_utf8(const std::u32string& s) {
    std::string out; out.reserve(s.size() * 2);
    for (char32_t cp : s) append_utf8(out, cp);
    return out;
}

std::u32string utf8_to_utf32(const std::string& s) {
    std::u32string out; out.reserve(s.size());
    size_t i = 0, n = s.size();
    while (i < n) {
        unsigned char c = (unsigned char)s[i];
        if (c < 0x80) { out += (char32_t)c; i += 1; }
        else if ((c >> 5) == 0x6) {
            if (i + 1 < n) out += ((c & 0x1F) << 6) | (s[i+1] & 0x3F);
            i += 2;
        } else if ((c >> 4) == 0xE) {
            if (i + 2 < n) out += ((c & 0x0F) << 12) | ((s[i+1] & 0x3F) << 6) | (s[i+2] & 0x3F);
            i += 3;
        } else if ((c >> 3) == 0x1E) {
            if (i + 3 < n)
                out += ((c & 0x07) << 18) | ((s[i+1] & 0x3F) << 12)
                     | ((s[i+2] & 0x3F) << 6) | (s[i+3] & 0x3F);
            i += 4;
        } else { i += 1; } // invalid byte, skip
    }
    return out;
}

// ---------------- Finglish key normalization ----------------
std::string normalize_finglish_key(const std::u32string& raw) {
    std::string k; k.reserve(raw.size());
    for (char32_t c : raw) {
        if (c >= U'A' && c <= U'Z') c = c + 32;
        if (c >= U'a' && c <= U'z') k += (char)c;
        else if (c == U'x') k += "kh";
        // digits and apostrophes kept out of keys
    }
    // digraph/collapse passes
    auto replace_all = [&](const std::string& from, const std::string& to) {
        if (from == to) return;
        size_t pos = 0;
        while ((pos = k.find(from, pos)) != std::string::npos) {
            k.replace(pos, from.size(), to);
            pos += to.size();
        }
    };
    replace_all("ck", "k");
    // long-vowel spellings collapse: aa->a, ee->i, oo->u  ("aadam"~"adam")
    replace_all("aa", "a");
    replace_all("ee", "i");
    replace_all("oo", "u");
    // long-o spelled with single o also collapses to u:  "dost"~"doost"
    replace_all("o", "u");
    return k;
}

std::string normalize_finglish_key(const std::string& utf8raw) {
    return normalize_finglish_key(utf8_to_utf32(utf8raw));
}

// ---------------- Persian normalization ----------------
std::u32string normalize_persian(const std::u32string& s) {
    std::u32string out; out.reserve(s.size());
    for (char32_t c : s) {
        switch (c) {
            case ARABIC_YEH:  c = PERSIAN_YEH; break;
            case ARABIC_KAF:  c = PERSIAN_KAF; break;
            case FATHA: case KASRA: case DAMMA: case SUKUN:
            case TANVIN_FATHA: case TASHDID: case TATWEEL:
                continue; // strip diacritics
            default: break;
        }
        out += c;
    }
    return out;
}

// ---------------- Tokenizer ----------------
static bool is_word_cp(char32_t c) {
    if ((c >= U'a' && c <= U'z') || (c >= U'A' && c <= U'Z')) return true;
    if (c >= U'0' && c <= U'9') return true;
    if (c == U'\'') return true;
    if (c >= 0x0600 && c <= 0x06FF) return true;   // Arabic block
    if (c == ZWNJ) return true;
    return false;
}

std::vector<Token> tokenize(const std::u32string& line) {
    std::vector<Token> out;
    size_t i = 0, n = line.size();
    while (i < n) {
        if (is_word_cp(line[i])) {
            size_t j = i;
            while (j < n && is_word_cp(line[j])) ++j;
            out.push_back({Token::Word, line.substr(i, j - i)});
            i = j;
        } else {
            size_t j = i;
            while (j < n && !is_word_cp(line[j])) ++j;
            out.push_back({Token::Sep, line.substr(i, j - i)});
            i = j;
        }
    }
    return out;
}

bool looks_ascii(const std::u32string& s) {
    for (char32_t c : s) if (c > 0x7F) return false;
    return true;
}

bool looks_technical(const std::u32string& w) {
    // url / email / path / camelCase / ALL-CAPS(2+) / leading digit / has '_'
    bool anyLower = false, anyUpper = false, anyLetter = false;
    size_t upperCount = 0;
    for (size_t i = 0; i < w.size(); ++i) {
        char32_t c = w[i];
        if ((c >= U'a' && c <= U'z') || (c >= U'A' && c <= U'Z')) anyLetter = true;
        if (c >= U'a' && c <= U'z') anyLower = true;
        if (c >= U'A' && c <= U'Z') { anyUpper = true; ++upperCount; }
        if (c == U'_' ) return true;
        if (c == U'.' ) {
            // path/url-ish: contains ./ inside (not trailing dot handled by caller)
            return true;
        }
        if (c >= U'0' && c <= U'9' && i == 0) return true;
    }
    if (anyUpper && !anyLower && upperCount >= 2) return true;  // USB, CPU
    if (anyUpper && anyLower && w.size() > 1) {
        // camelCase: upper not at position 0
        for (size_t i = 1; i < w.size(); ++i)
            if (w[i] >= U'A' && w[i] <= U'Z') return true;
    }
    return anyLetter ? false : false;
}

} // namespace mk
