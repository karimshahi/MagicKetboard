// Magic Keyboard V2 — lexicon: loads dictionary.tsv (UTF-8, TSV)
// Format per line:  finglish \t persian \t pos(0-12) \t rank
// The same finglish key may appear multiple times (candidates).
#pragma once
#include "types.h"
#include <string>
#include <vector>
#include <unordered_map>

namespace mk {

class Lexicon {
public:
    // Load from TSV text (UTF-8). Returns number of entries loaded.
    size_t load_tsv(const std::string& utf8tsv);

    // Register a single entry programmatically (used by tests).
    uint32_t add(const std::string& finglish, const std::u32string& persian,
                 Pos pos, uint32_t rank);

    size_t entry_count() const { return entries_.size(); }
    size_t key_count()  const { return index_.size(); }

    // All candidate ids for a normalized finglish key (may be empty).
    const std::vector<uint32_t>* find(const std::string& normKey) const;

    // V3: fuzzy correction — find the closest dictionary key within
    // `maxDist` (Damerau-Levenshtein: insert/delete/substitute/transpose).
    // Candidates whose best rank exceeds `maxRank` are ignored so rare
    // words never win over a phonetic guess.  On success, *out gets the
    // candidate ids of the single best key (ties broken by key rank).
    bool fuzzy_find(const std::string& normKey, int maxDist,
                    uint32_t maxRank, std::vector<uint32_t>* outIds) const;

    const LexEntry& entry(uint32_t id) const { return entries_[id]; }

private:
    std::vector<LexEntry> entries_;
    std::unordered_map<std::string, std::vector<uint32_t>> index_;
};

} // namespace mk
