// Magic Keyboard V2 — rule-based phonetic fallback
// For words missing from the dictionary: approximate Finglish -> Persian.
// LOW confidence (0.35). Can be disabled in settings.
#pragma once
#include "types.h"
#include <string>

namespace mk {

// Transliterate a raw Latin word to Persian script.
// Returns false when the word contains characters that make no sense.
bool phonetic_translit(const std::u32string& raw, std::u32string* out);

} // namespace mk
