// Magic Keyboard V2 — engine test suite
// Builds on Linux like the Windows app does: Lexicon loads
// resources/dictionary.tsv, Converter runs the same pipeline.
#include "../core/converter.h"
#include "../core/lexicon.h"
#include "../core/loanwords.h"
#include "../core/string_utils.h"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>

using namespace mk;

static int g_pass = 0, g_fail = 0;

static void expect(bool ok, const std::string& name,
                   const std::string& got, const std::string& want) {
    if (ok) { ++g_pass; }
    else {
        ++g_fail;
        printf("  FAIL %-34s got=[%s] want=[%s]\n", name.c_str(),
               got.c_str(), want.c_str());
    }
}

static void expect_fa(Converter& cv, const std::string& input,
                      const std::string& want, const char* name) {
    std::u32string out = cv.convert_line(utf8_to_utf32(input));
    std::string got = utf32_to_utf8(out);
    expect(got == want, name, got, want);
}

static void expect_word(Converter& cv, const std::string& input,
                        const std::string& want, const char* name) {
    WordResult r = cv.convert_word(utf8_to_utf32(input), cv.history());
    std::string got = (r.action == WordAction::Replace)
                        ? utf32_to_utf8(r.output) : "<keep:" + input + ">";
    expect(got == want, name, got, want);
}

static void expect_reason(Converter& cv, const std::string& input,
                          const std::string& want, const char* name) {
    WordResult r = cv.convert_word(utf8_to_utf32(input), cv.history());
    expect(r.reason == want, name, r.reason, want);
}

int main(int argc, char** argv) {
    std::string dictPath = "resources/dictionary.tsv";
    if (argc > 1) dictPath = argv[1];

    std::ifstream f(dictPath, std::ios::binary);
    if (!f) { printf("cannot open %s\n", dictPath.c_str()); return 2; }
    std::stringstream ss; ss << f.rdbuf();
    Lexicon lex;
    size_t n = lex.load_tsv(ss.str());
    printf("lexicon: %zu entries, %zu keys\n", n, lex.key_count());

    LoanwordTable loans;
    Converter cv;
    cv.set_lexicon(&lex);
    cv.set_loanwords(&loans);

    EngineSettings s = cv.settings();
    s.loanwordsConvert = true;   // V2 default per user request
    cv.set_settings(s);

    printf("\n== 1) vocabe asli (V1 acceptance set) ==\n");
    expect_fa(cv, "salam",           "سلام",          "salam");
    expect_fa(cv, "ketab",           "کتاب",          "ketab");
    expect_fa(cv, "khane",           "خانه",          "khane");
    expect_fa(cv, "doost",           "دوست",          "doost");
    expect_fa(cv, "ziba",            "زیبا",          "ziba");
    expect_fa(cv, "iran",            "ایران",         "iran");
    expect_fa(cv, "tehran",          "تهران",         "tehran");
    expect_fa(cv, "panir",           "پنیر",          "panir");
    expect_fa(cv, "donya",           "دنیا",          "donya");
    expect_fa(cv, "esm",             "اسم",           "esm");

    printf("\n== 2) barname nevis (masaleye asli Karbar) ==\n");
    expect_fa(cv, "barname nevis",   "برنامه نویس",   "barname nevis");

    printf("\n== 3) af'ale ba nim-fasele ==\n");
    expect_fa(cv, "miraftam",        "می\u200cرفتم",   "miraftam");
    expect_fa(cv, "mikhonam",        "می\u200cخونم",   "mikhonam");
    expect_fa(cv, "minevisam",       "می\u200cنویسم",  "minevisam");
    expect_fa(cv, "midanam",         "می\u200cدانم",   "midanam");
    expect_fa(cv, "rafteast",        "رفته\u200cاست",  "rafteast");
    expect_fa(cv, "naraftam",        "نرفتم",         "naraftam");
    expect_fa(cv, "beravam",         "بروم",          "beravam");
    expect_fa(cv, "boro",            "برو",           "boro");
    expect_fa(cv, "naro",            "نرو",           "naro");
    expect_fa(cv, "bekhor",          "بخور",          "bekhor");

    printf("\n== 4) mo'addala-ye Dare (kharabi V1) ==\n");
    cv.reset_history();
    expect_word(cv, "dare",          "داره",          "dare alone");
    expect_fa(cv, "u dare",          "او داره",        "u dare");
    expect_fa(cv, "ali dare",        "علی داره",       "ali dare");
    expect_fa(cv, "az dare",         "از دره",         "az dare");
    expect_fa(cv, "dar dare",        "در دره",         "dar dare");
    // subject-like previous word must force the auxiliary reading
    expect_word(cv, "dare", "داره", "dare top-rank");

    printf("\n== 5) vam-vazheha-ye engelisi-farsi (V2) ==\n");
    expect_word(cv, "system",        "سیستم",         "system->سیستم");
    expect_word(cv, "test",          "تست",           "test->تست");
    expect_word(cv, "film",          "فیلم",          "film->فیلم");
    expect_word(cv, "computer",      "کامپیوتر",      "computer");
    expect_word(cv, "internet",      "اینترنت",       "internet");
    expect_fa(cv, "in yek test ast", "این یک تست است",  "in yek test ast");

    // settings off -> keep english
    {
        EngineSettings s2 = cv.settings();
        s2.loanwordsConvert = false;
        cv.set_settings(s2);
        expect_reason(cv, "system", "loanword-kept", "policy=preserve keeps");
        expect_word(cv, "system", "<keep:system>", "policy=preserve output");
        s2.loanwordsConvert = true;
        cv.set_settings(s2);
    }

    printf("\n== 6) pasvand-ha (suffix) ==\n");
    expect_word(cv, "ketabam",       "کتابم",         "ketabam");
    expect_word(cv, "ketabat",       "کتابت",         "ketabat");
    expect_word(cv, "ketabash",      "کتابش",         "ketabash");
    expect_fa(cv, "ketabha",         "کتاب\u200cها",   "ketabha dict");
    expect_fa(cv, "bozorgtar",       "بزرگتر",        "bozorgtar");
    expect_fa(cv, "bozorgtarin",     "بزرگترین",      "bozorgtarin");
    expect_word(cv, "doostam",       "دوستم",         "doostam");

    printf("\n== 4b) gozaresh-e dastoori ==\n");
    expect_fa(cv, "man danestan",    "من دانستن",     "man danestan");

    printf("\n== 7) jomle-ha ==\n");
    expect_fa(cv, "salam donya",                  "سلام دنیا",        "salam donya");
    expect_fa(cv, "man ketab mikhonam",           "من کتاب می\u200cخونم","man ketab mikhonam");
    expect_fa(cv, "man be tehran miravam",        "من به تهران می\u200cروم","man be tehran miravam");
    expect_fa(cv, "in ketab man ast",             "این کتاب من است",    "in ketab man ast");
    expect_fa(cv, "ali be madrese raft",          "علی به مدرسه رفت",   "ali be madrese raft");
    expect_fa(cv, "salam. man ali hastam.",       "سلام. من علی هستم.", "salam. man ali hastam.");
    expect_fa(cv, "man irani hastam",             "من ایرانی هستم",     "man irani hastam");

    printf("\n== 8) hefaz-e moton-e engelisi/fanny ==\n");
    expect_reason(cv, "USB",       "english", "USB caps");
    expect_reason(cv, "myVar",     "english", "camelCase");
    expect_reason(cv, "the",       "english", "stopword the");
    expect_reason(cv, "and",       "english", "stopword and");
    expect_reason(cv, "3dmax",     "english", "digit-led");
    expect_fa(cv, "and or the",    "and or the", "english sentence kept");

    printf("\n== 9) pasokht-e avai (fallback) ==\n");
    expect_word(cv, "pesarak", "پسرک", "pesarak");
    expect_word(cv, "mard",    "مرد",  "mard");
    expect_word(cv, "pesar",   "پسر",  "pesar");
    {
        EngineSettings s3 = cv.settings();
        s3.phoneticFallback = false;
        cv.set_settings(s3);
        expect_reason(cv, "pesarak", "no-match", "fallback disabled");
        s3.phoneticFallback = true;
        cv.set_settings(s3);
    }

    printf("\n== 10) tarikh va roozha ==\n");
    expect_fa(cv, "emrooz doshanbe ast", "امروز دوشنبه است", "emrooz doshanbe");
    expect_fa(cv, "norooz", "نوروز", "norooz");

    printf("\n== 11) aryaam va c++ confidence ==\n");
    {
        WordResult r = cv.convert_word(utf8_to_utf32("salam"), {});
        expect(r.confidence > 0.9, "salam confidence", std::to_string(r.confidence), ">0.9");
    }

    // ------- lexicon coverage -------
    printf("\n== 12) pushesh-e vajanlugh ==\n");
    expect(lex.key_count() >= 10000, "keys>=10000",
           std::to_string(lex.key_count()), ">=10000");

    // ---------------- V3 ----------------
    printf("\n== 13) V3: vazhegan-e jadid (gozaresh-e karbar) ==\n");
    // exactly the words the user typed with V2 that came out wrong:
    //  "در تنزیمت که ورد میشی فنت اا کملن نسزگر هستند ... کتبرد مجیک 2"
    expect_fa(cv, "tanzimat", "تنظیمات", "tanzimat");
    expect_fa(cv, "tanzim",   "تنظیم",   "tanzim");
    expect_fa(cv, "kibord",   "کیبورد",  "kibord");
    expect_fa(cv, "eslah",    "اصلاح",   "eslah");
    expect_fa(cv, "irad",     "ایراد",   "irad");
    expect_fa(cv, "iradi",    "ایرادی",  "iradi");
    expect_fa(cv, "fnt",      "فونت",    "fnt");
    expect_fa(cv, "verzhon",  "ورژن",    "verzhon");
    expect_fa(cv, "nosxe",    "نسخه",    "nosxe");
    expect_fa(cv, "moshkel",  "مشکل",    "moshkel");
    expect_fa(cv, "tanzimat ro eslah kon",
              "تنظیمات رو اصلاح کن", "tanzimat ro eslah kon");

    printf("\n== 14) V3: fuzzy (eslah-e hushmand-e ghalat-e taypi) ==\n");
    expect_fa(cv, "esla",      "اصلاح",   "esla -> eslah");
    expect_fa(cv, "tanzimatt", "تنظیمات", "tanzimatt -> tanzimat");
    expect_fa(cv, "ktbord",    "کیبورد",  "ktbord -> kibord");
    expect_fa(cv, "tanzzimat", "تنظیمات", "tanzzimat (dup z)");
    expect_reason(cv, "esla", "fuzzy", "esla reason=fuzzy");
    // a real diminutive must NOT collapse to its stem (lenDiff gate)
    expect_fa(cv, "pesarak", "پسرک", "pesarak stays phonetic");
    // english leftovers must not get "corrected" into persian
    expect_reason(cv, "and", "english", "stopword before fuzzy");

    printf("\n== 15) V3: avangari behboud-yafte (fallback) ==\n");
    expect_fa(cv, "robot", "روبوت", "robot (mid o -> و)");
    expect_fa(cv, "jamah", "جماه",  "jamah (final ah -> اه)");
    expect_fa(cv, "harja", "هرجا",  "harja (dict, unchanged)");

    printf("\n=============================================\n");
    printf("PASS: %d   FAIL: %d\n", g_pass, g_fail);
    return g_fail == 0 ? 0 : 1;
}
